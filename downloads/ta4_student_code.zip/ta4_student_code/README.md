# Finance 4 TA4 Student Code

This folder is the **student-facing TA4 package**. It is separate from the website source on purpose.

## What students should do

1. Open `Finance4_TA4_Student.Rproj`
2. Open `main.R`
3. Run:

```r
source("main.R")
```

That script will:

- build a compact synthetic bank-year panel with staggered treatment timing,
- run the TA4 staggered Difference-in-Differences analysis,
- export LaTeX tables to `output/tables/`,
- save figures, tables, and model outputs into `output/`.

## What is inside

```text
ta4_student_code/
  code/
    00_utils.R
    01_build_ta4_data.R
    02_ta4_staggered_did.R
  Finance4_TA4_Student.Rproj
  main.R
  run_ta4.R
```

## Output files

After running the code, students should find:

- `data/bank_panel.rds`
- `data/bank_panel.csv`
- `data/data_dictionary.csv`
- `output/figures/ta4_treatment_timing.png`
- `output/figures/ta4_cohort_trends.png`
- `output/figures/ta4_event_study.png`
- `output/figures/ta4_twfe_vs_sunab.png`
- `output/tables/ta4_data_summary.csv`
- `output/tables/ta4_cohort_summary.csv`
- `output/tables/ta4_cohort_summary.tex`
- `output/tables/ta4_event_study_table.csv`
- `output/tables/ta4_estimator_comparison.csv`
- `output/tables/ta4_estimator_comparison.tex`
- `output/tables/ta4_model_table.csv`
- `output/tables/ta4_regression.tex`
- `output/models/ta4_models.rds`
- `output/text/ta4_note.txt`
- `output/text/data_build_summary.txt`

## Packages

The TA4 package expects these packages to be installed:

- `broom`
- `dplyr`
- `fixest`
- `ggplot2`
- `knitr`
- `kableExtra`
- `purrr`
- `readr`
- `stringr`
- `tidyr`

If a package is missing, the script will stop and tell the student which one to install.
