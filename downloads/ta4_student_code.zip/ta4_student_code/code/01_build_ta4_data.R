# ============================================================
#  FINANCE 4 — TA SESSION 4
#  Script 01: Build the TA4 staggered-DiD dataset
# ------------------------------------------------------------
#  Empirical question of TA4:
#
#      What is the effect of crossing the $10bn regulatory
#      threshold on bank loan growth?
#
#  This script generates a compact synthetic bank-year panel that
#  mirrors the dataset used in the lecture website. It is built so
#  that:
#    - Banks cross the threshold in different years (staggered).
#    - Some banks never cross (clean controls).
#    - The treatment effect is heterogeneous across cohorts and
#      grows dynamically with time-since-treatment.
#
#  The combination of staggered timing + heterogeneous + dynamic
#  effects is exactly the situation in which two-way fixed effects
#  (TWFE) gives biased estimates and Sun & Abraham (2021) helps.
# ============================================================

source("code/00_utils.R")
load_finance4_packages()

set.seed(4404)

ensure_dir("data")
ensure_dir("output/figures")
ensure_dir("output/models")
ensure_dir("output/tables")
ensure_dir("output/text")

years <- 2012:2023
n_banks <- 80

# ---- Bank fundamentals -------------------------------------
# Each bank has its own permanent characteristics that shift the
# level of loan growth (bank fixed effects in spirit).

banks <- tibble::tibble(
  bank_id = sprintf("B%03d", 1:n_banks),
  bank_fe = rnorm(n_banks, 0, 0.012),
  initial_assets_bn = pmax(rnorm(n_banks, 8.0, 2.5), 2.0),
  asset_drift = pmax(rnorm(n_banks, 0.04, 0.015), 0)
)

# ---- Year-level macro dynamics -----------------------------
# A common macro cycle plus a regulatory-intensity index that grows
# over time (so later cohorts face stricter supervision when treated).

year_tbl <- tibble::tibble(
  year = years,
  macro_cycle = c(-0.015, -0.005, 0.010, 0.015, 0.020,
                  0.018, 0.014, 0.005, -0.020, 0.005,
                  -0.025, 0.010),
  regulatory_intensity = seq(0.20, 0.55, length.out = length(years))
)

# ---- Build the bank-year panel -----------------------------
# 1) Simulate asset growth and find the first year (if any) when
#    the bank crosses the $10bn threshold.
# 2) Define treatment and event time.
# 3) Build loan_growth with a heterogeneous, dynamic treatment
#    effect that depends on the regulatory intensity at the moment
#    of crossing.

bank_panel <- tidyr::crossing(
  bank_id = banks$bank_id,
  year = years
) |>
  dplyr::left_join(banks, by = "bank_id") |>
  dplyr::left_join(year_tbl, by = "year") |>
  dplyr::group_by(bank_id) |>
  dplyr::arrange(year, .by_group = TRUE) |>
  dplyr::mutate(
    asset_shock = rnorm(dplyr::n(), 0, 0.025),
    asset_growth_rate = pmax(asset_drift + 0.30 * macro_cycle + asset_shock, -0.04),
    assets_bn = initial_assets_bn * cumprod(1 + asset_growth_rate),
    first_treat = {
      crossing_years <- year[assets_bn >= 10]
      if (length(crossing_years) == 0L) 0L else as.integer(min(crossing_years))
    },
    treated = as.integer(first_treat > 0L & year >= first_treat),
    event_time = dplyr::if_else(
      first_treat > 0L,
      as.integer(year - first_treat),
      NA_integer_
    )
  ) |>
  dplyr::ungroup()

# ---- Heterogeneous and dynamic treatment effect ------------
# The post-treatment effect on loan growth is:
#   - negative on average (regulatory burden cuts lending)
#   - larger in magnitude when regulatory intensity is high at
#     the moment of crossing (cohort heterogeneity)
#   - growing slowly with time since treatment (dynamic effect)

regulatory_at_crossing <- bank_panel |>
  dplyr::filter(first_treat > 0L, year == first_treat) |>
  dplyr::distinct(bank_id, regulatory_at_crossing = regulatory_intensity)

bank_panel <- bank_panel |>
  dplyr::left_join(regulatory_at_crossing, by = "bank_id") |>
  dplyr::mutate(
    cohort_effect = dplyr::if_else(
      is.na(regulatory_at_crossing),
      0,
      -0.030 * regulatory_at_crossing
    ),
    dynamic_effect = dplyr::if_else(
      treated == 1L & !is.na(event_time),
      cohort_effect * (1 + 0.10 * event_time),
      0
    ),
    loan_growth = 0.030 +
      bank_fe +
      0.40 * macro_cycle +
      dynamic_effect +
      rnorm(dplyr::n(), 0, 0.012)
  )

# ---- Trim and save the panel that the analysis script reads ----

bank_panel <- bank_panel |>
  dplyr::select(
    bank_id,
    year,
    assets_bn,
    loan_growth,
    macro_cycle,
    regulatory_intensity,
    first_treat,
    treated,
    event_time
  )

data_dictionary <- tibble::tribble(
  ~variable, ~definition, ~role_in_design,
  "bank_id", "Synthetic bank identifier", "Panel identifier",
  "year", "Calendar year (2012-2023)", "Time identifier",
  "assets_bn", "Bank assets in USD billions", "Running variable that triggers treatment",
  "loan_growth", "Annual loan growth rate (decimal)", "Outcome of interest",
  "macro_cycle", "Common macro shifter for that year", "Aggregate trend",
  "regulatory_intensity", "Index of regulatory burden in that year", "Drives cohort heterogeneity",
  "first_treat", "First year in which the bank crossed $10bn (0 if never)", "Cohort variable for sunab()",
  "treated", "1 once the bank has crossed the threshold and onwards", "Treatment indicator",
  "event_time", "Years since first crossing the threshold", "Event-time dimension"
)

save_rds_finance4(bank_panel, "data/bank_panel.rds")
write_csv_finance4(bank_panel, "data/bank_panel.csv")
write_csv_finance4(data_dictionary, "data/data_dictionary.csv")

write_text_finance4(
  c(
    "TA4 teaching data were built successfully.",
    paste("Bank-years:", nrow(bank_panel)),
    paste("Banks:", dplyr::n_distinct(bank_panel$bank_id)),
    paste("Years:", min(bank_panel$year), "-", max(bank_panel$year)),
    paste(
      "Ever-treated banks:",
      dplyr::n_distinct(bank_panel$bank_id[bank_panel$first_treat > 0])
    ),
    paste(
      "Never-treated banks:",
      dplyr::n_distinct(bank_panel$bank_id[bank_panel$first_treat == 0])
    )
  ),
  "output/text/data_build_summary.txt"
)
