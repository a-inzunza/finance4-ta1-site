# ============================================================
#  FINANCE 4 — TA SESSION 4
#  Script 02: Staggered Difference-in-Differences analysis
# ------------------------------------------------------------
#  Main empirical question:
#
#      What is the effect of crossing the $10bn regulatory
#      threshold on bank loan growth?
#
#  We compare two estimators on the same data:
#    (a) Naive two-way fixed effects (TWFE)
#    (b) Sun & Abraham (2021) cohort-weighted event study
#
#  When (a) and (b) disagree, that is the empirical signature of
#  the heterogeneity / dynamic-effect bias in TWFE that the modern
#  staggered-DiD literature warns about.
# ============================================================

source("code/00_utils.R")
load_finance4_packages()

bank_panel <- readRDS("data/bank_panel.rds")


# ############################################################
#  SECTION 1 — BUILD THE TA4 PANEL AND COHORT STRUCTURE
# ############################################################
# Banks already above $10bn in the very first sample year have NO
# pre-treatment observations and cannot be used in an event study.
# We drop them and keep:
#   - Never-treated banks (first_treat == 0)
#   - Banks that cross the threshold from 2013 onward
#
# We also build "first_treat_sa", a recoded cohort variable that
# fixest::sunab() understands: never-treated banks must have a
# cohort value GREATER than the maximum period, so we relabel
# them as 9999.

ta4_panel <- bank_panel |>
  dplyr::filter(first_treat == 0L | first_treat >= 2013L) |>
  dplyr::mutate(
    first_treat_sa = dplyr::if_else(
      first_treat == 0L,
      9999L,
      as.integer(first_treat)
    )
  )

ta4_data_summary <- ta4_panel |>
  dplyr::summarise(
    n_obs = dplyr::n(),
    n_banks = dplyr::n_distinct(bank_id),
    n_ever_treated = dplyr::n_distinct(bank_id[first_treat > 0]),
    n_never_treated = dplyr::n_distinct(bank_id[first_treat == 0]),
    first_year = min(year),
    last_year = max(year)
  )

cohort_summary <- ta4_panel |>
  dplyr::distinct(bank_id, first_treat) |>
  dplyr::group_by(first_treat) |>
  dplyr::summarise(n_banks = dplyr::n(), .groups = "drop") |>
  dplyr::mutate(
    cohort_label = dplyr::if_else(
      first_treat == 0L,
      "Never treated",
      paste0("Treated in ", first_treat)
    )
  ) |>
  dplyr::arrange(first_treat) |>
  dplyr::select(cohort_label, first_treat, n_banks)


# ############################################################
#  SECTION 2 — TREATMENT TIMING HEATMAP
# ############################################################

bank_order <- ta4_panel |>
  dplyr::distinct(bank_id, first_treat) |>
  dplyr::mutate(
    sort_key = dplyr::if_else(first_treat == 0L, 9999L, as.integer(first_treat))
  ) |>
  dplyr::arrange(sort_key, bank_id) |>
  dplyr::mutate(bank_order = dplyr::row_number()) |>
  dplyr::select(bank_id, bank_order)

heatmap_data <- ta4_panel |>
  dplyr::left_join(bank_order, by = "bank_id")

treatment_timing_plot <- ggplot2::ggplot(
  heatmap_data,
  ggplot2::aes(x = year, y = bank_order, fill = factor(treated))
) +
  ggplot2::geom_tile(color = "white", linewidth = 0.1) +
  ggplot2::scale_fill_manual(
    values = c("0" = "#dcdbd8", "1" = "#0f5f54"),
    labels = c("0" = "Untreated", "1" = "Treated"),
    name = NULL
  ) +
  ggplot2::labs(
    title = "Treatment timing: when banks cross the $10bn threshold",
    subtitle = "Each row is a bank, sorted by cohort. Never-treated banks are at the top.",
    x = "Year",
    y = "Banks (sorted by treatment cohort)"
  ) +
  theme_finance4()


# ############################################################
#  SECTION 3 — PRE-TREATMENT TRENDS BY COHORT
# ############################################################

cohort_trends <- ta4_panel |>
  dplyr::mutate(
    cohort_group = dplyr::case_when(
      first_treat == 0L ~ "Never treated",
      first_treat <= 2016L ~ "Early treated (2013-2016)",
      first_treat <= 2019L ~ "Mid treated (2017-2019)",
      TRUE ~ "Late treated (2020-2023)"
    )
  ) |>
  dplyr::group_by(cohort_group, year) |>
  dplyr::summarise(
    mean_loan_growth = mean(loan_growth, na.rm = TRUE),
    n_banks = dplyr::n(),
    .groups = "drop"
  )

cohort_trends_plot <- ggplot2::ggplot(
  cohort_trends,
  ggplot2::aes(x = year, y = mean_loan_growth, color = cohort_group)
) +
  ggplot2::geom_line(linewidth = 1) +
  ggplot2::geom_point(size = 2) +
  ggplot2::labs(
    title = "Loan growth by treatment cohort",
    subtitle = "Visual check of trends before and after each cohort's threshold crossing.",
    x = "Year",
    y = "Average loan growth"
  ) +
  theme_finance4()


# ############################################################
#  SECTION 4 — NAIVE TWO-WAY FIXED EFFECTS (TWFE)
# ############################################################
#  Y_{i,t} = alpha_i + gamma_t + beta * D_{i,t} + eps_{i,t}
#
#  D_{i,t} = 1 once bank i has crossed the $10bn threshold.

twfe_model <- fixest::feols(
  loan_growth ~ treated | bank_id + year,
  cluster = ~bank_id,
  data = ta4_panel
)


# ############################################################
#  SECTION 5 — SUN & ABRAHAM EVENT-STUDY ESTIMATES
# ############################################################
# fixest::sunab() automatically:
#   - estimates ATT(cohort, event-time) for every cohort,
#   - aggregates them with non-negative weights,
#   - never uses already-treated units as controls.

sunab_model <- fixest::feols(
  loan_growth ~ sunab(first_treat_sa, year) | bank_id + year,
  cluster = ~bank_id,
  data = ta4_panel
)

sunab_event_table <- broom::tidy(sunab_model) |>
  dplyr::filter(stringr::str_detect(term, "year::")) |>
  dplyr::mutate(
    event_time = as.integer(stringr::str_extract(term, "-?\\d+")),
    conf_low = estimate - 1.96 * std.error,
    conf_high = estimate + 1.96 * std.error
  ) |>
  dplyr::arrange(event_time)


# ############################################################
#  SECTION 6 — EVENT-STUDY PLOT
# ############################################################

event_study_plot <- ggplot2::ggplot(
  sunab_event_table,
  ggplot2::aes(x = event_time, y = estimate)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "#9a462f") +
  ggplot2::geom_vline(xintercept = -1, linetype = "dotted", color = "#6c757d") +
  ggplot2::geom_ribbon(
    ggplot2::aes(ymin = conf_low, ymax = conf_high),
    fill = "#0f5f54",
    alpha = 0.15
  ) +
  ggplot2::geom_line(color = "#0f5f54", linewidth = 1) +
  ggplot2::geom_point(color = "#0f5f54", size = 2) +
  ggplot2::labs(
    title = "Sun & Abraham event-study estimates",
    subtitle = "Cohort-weighted dynamic ATTs around the $10bn threshold crossing.",
    x = "Years since crossing the threshold",
    y = "ATT on loan growth"
  ) +
  theme_finance4()


# ############################################################
#  SECTION 7 — TWFE vs SUN & ABRAHAM COMPARISON
# ############################################################

twfe_tidy <- broom::tidy(twfe_model)
twfe_estimate <- twfe_tidy$estimate[twfe_tidy$term == "treated"]
twfe_se <- twfe_tidy$std.error[twfe_tidy$term == "treated"]

sunab_agg_summary <- summary(sunab_model, agg = "ATT")
sunab_agg_table <- sunab_agg_summary$coeftable
sunab_att_estimate <- sunab_agg_table[1, 1]
sunab_att_se <- sunab_agg_table[1, 2]

estimator_comparison <- tibble::tibble(
  estimator = factor(
    c("Naive TWFE", "Sun & Abraham (aggregate ATT)"),
    levels = c("Naive TWFE", "Sun & Abraham (aggregate ATT)")
  ),
  estimate = c(twfe_estimate, sunab_att_estimate),
  std.error = c(twfe_se, sunab_att_se)
) |>
  dplyr::mutate(
    conf_low = estimate - 1.96 * std.error,
    conf_high = estimate + 1.96 * std.error
  )

estimator_comparison_plot <- ggplot2::ggplot(
  estimator_comparison,
  ggplot2::aes(x = estimator, y = estimate)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "#6c757d") +
  ggplot2::geom_pointrange(
    ggplot2::aes(ymin = conf_low, ymax = conf_high),
    color = "#9a462f",
    linewidth = 0.7,
    size = 0.8
  ) +
  ggplot2::labs(
    title = "Naive TWFE vs Sun & Abraham aggregate ATT",
    subtitle = "When the two estimators disagree, TWFE is contaminated by heterogeneity bias.",
    x = NULL,
    y = "Estimated effect on loan growth"
  ) +
  theme_finance4()


# ############################################################
#  SECTION 8 — RESULTS TABLE IN TEACHING ORDER
# ############################################################

ta4_models <- list(
  TWFE = twfe_model,
  `Sun & Abraham (event-study)` = sunab_model
)

ta4_model_table <- dplyr::bind_rows(
  twfe_tidy |>
    dplyr::mutate(model = "TWFE"),
  broom::tidy(sunab_model) |>
    dplyr::mutate(model = "Sun & Abraham (event-study)"),
  tibble::tibble(
    term = "ATT",
    estimate = sunab_att_estimate,
    std.error = sunab_att_se,
    statistic = sunab_agg_table[1, 3],
    p.value = sunab_agg_table[1, 4],
    model = "Sun & Abraham (aggregate ATT)"
  )
) |>
  dplyr::select(model, dplyr::everything())


# ############################################################
#  SECTION 9 — LATEX EXPORT
# ############################################################

cohort_summary_latex <- knitr::kable(
  cohort_summary |> dplyr::select(cohort_label, n_banks),
  format = "latex",
  booktabs = TRUE,
  digits = 0,
  col.names = c("Cohort", "Number of banks"),
  caption = "Treatment cohorts in the TA4 panel"
) |>
  kableExtra::kable_styling(
    latex_options = c("hold_position"),
    full_width = FALSE
  )

estimator_comparison_latex <- knitr::kable(
  estimator_comparison |>
    dplyr::select(estimator, estimate, std.error, conf_low, conf_high),
  format = "latex",
  booktabs = TRUE,
  digits = 4,
  col.names = c("Estimator", "Estimate", "Std. error", "95% CI low", "95% CI high"),
  caption = "Naive TWFE vs Sun \\& Abraham aggregate ATT"
) |>
  kableExtra::kable_styling(
    latex_options = c("hold_position"),
    full_width = FALSE
  )

regression_latex <- fixest::etable(
  ta4_models,
  cluster = ~bank_id,
  tex = TRUE
)


# ############################################################
#  SECTION 10 — SAVE OUTPUTS (in the same order as above)
# ############################################################

write_csv_finance4(ta4_data_summary, "output/tables/ta4_data_summary.csv")
write_csv_finance4(cohort_summary, "output/tables/ta4_cohort_summary.csv")
write_csv_finance4(sunab_event_table, "output/tables/ta4_event_study_table.csv")
write_csv_finance4(estimator_comparison, "output/tables/ta4_estimator_comparison.csv")
write_csv_finance4(ta4_model_table, "output/tables/ta4_model_table.csv")

save_plot_finance4(treatment_timing_plot, "output/figures/ta4_treatment_timing.png")
save_plot_finance4(cohort_trends_plot, "output/figures/ta4_cohort_trends.png")
save_plot_finance4(event_study_plot, "output/figures/ta4_event_study.png")
save_plot_finance4(estimator_comparison_plot, "output/figures/ta4_twfe_vs_sunab.png")

save_rds_finance4(ta4_models, "output/models/ta4_models.rds")

write_tex_finance4(cohort_summary_latex, "output/tables/ta4_cohort_summary.tex")
write_tex_finance4(estimator_comparison_latex, "output/tables/ta4_estimator_comparison.tex")
write_tex_finance4(regression_latex, "output/tables/ta4_regression.tex")

write_text_finance4(
  c(
    "TA4 teaching note",
    "",
    "Research question: what is the effect of crossing the $10bn",
    "regulatory threshold on bank loan growth?",
    "",
    "1. With staggered treatment timing, banks cross the threshold",
    "   in different years. Some never cross.",
    "2. Naive TWFE pools all 2x2 comparisons, including 'forbidden'",
    "   ones using already-treated banks as controls.",
    "3. With heterogeneous or dynamic treatment effects, this gives",
    "   a biased TWFE estimate.",
    "4. Sun & Abraham (2021) computes cohort x event-time ATTs and",
    "   aggregates them properly, never using already-treated units",
    "   as controls.",
    "5. When TWFE and Sun & Abraham disagree, that is the signature",
    "   of heterogeneity / dynamic-effect bias in TWFE."
  ),
  "output/text/ta4_note.txt"
)
