# Finance 4 TA1 Student Code

This folder is the **student-facing TA1 package**. It is separate from the webpage source on purpose.

## What students should do

1. Open `Finance4_TA1_Student.Rproj`
2. Open `main.R`
3. Run:

```r
source("main.R")
```

That script will:

- build the TA1 teaching dataset,
- run the TA1 fixed-effects analysis,
- run the endogeneity simulation (OVB demo),
- export LaTeX tables to `output/tables/`,
- save figures, tables, and model outputs into `output/`.

## What is inside

```text
ta1_student_code/
  code/
    00_utils.R
    01_build_ta1_data.R
    02_ta1_fixed_effects.R
  Finance4_TA1_Student.Rproj
  main.R
  run_ta1.R
```

## Output files

After running the code, students should find:

- `data/master_bank_panel.rds`
- `data/master_bank_panel.csv`
- `data/bank_county_panel.rds`
- `data/data_dictionary.csv`
- `output/figures/ta1_loan_growth_trend.png`
- `output/figures/ta1_endogeneity_simulation.png`
- `output/tables/ta1_descriptives.csv`
- `output/tables/ta1_descriptives.tex`
- `output/tables/ta1_regression.tex`
- `output/tables/ta1_model_table.csv`
- `output/models/ta1_models.rds`
- `output/text/ta1_note.txt`

## Packages

The TA1 package expects these packages to be installed:

- `broom`
- `dplyr`
- `fixest`
- `ggplot2`
- `knitr`
- `kableExtra`
- `purrr`
- `readr`
- `stringr`
- `tidyr`

If a package is missing, the script will stop and tell the student which one to install.
