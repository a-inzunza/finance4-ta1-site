# ============================================================
#  FINANCE 4 — TA SESSION 1
#  Script 01: Build the TA1 teaching dataset
# ------------------------------------------------------------
#  This script creates the synthetic bank-year panel used in
#  TA1.  Run it once; every later script reads from data/.
#
#  Students do NOT need to modify this file.  It exists so you
#  can inspect the data-generating process (DGP) and understand
#  what "ground truth" looks like before estimation.
# ============================================================

source("code/00_utils.R")
load_finance4_packages()

set.seed(4404)

ensure_dir("data")
ensure_dir("output/figures")
ensure_dir("output/models")
ensure_dir("output/tables")
ensure_dir("output/text")

# ---- Global parameters ---------------------------------------

years <- 2012:2023
regions <- c("North", "South", "Midwest", "West")

# ---- Bank cross-section (80 banks) ---------------------------
# Each bank has fixed characteristics drawn once:
#   - region, size (initial_assets_bn), capital_base, liquidity,
#     uninsured deposits, securities exposure, political ties,
#     risk culture.
# public_bank = 1 for the 40 largest (top half by assets).

banks <- tibble::tibble(
  bank_id = sprintf("B%03d", 1:80),
  bank_name = stringr::str_c("Bank ", stringr::str_pad(1:80, width = 3, pad = "0")),
  region = sample(regions, 80, replace = TRUE),
  bank_fe = rnorm(80, 0, 0.35),
  initial_assets_bn = round(exp(rnorm(80, log(8.8), 0.40)), 2),
  capital_base = pmin(pmax(rnorm(80, 0.115, 0.015), 0.075), 0.18),
  liquidity_base = pmin(pmax(rnorm(80, 0.18, 0.04), 0.08), 0.32),
  uninsured_share = pmin(pmax(rbeta(80, 2.8, 5.5), 0.05), 0.65),
  securities_exposure = pmin(pmax(rbeta(80, 2.2, 2.8), 0.05), 0.85),
  political_connection = pmin(pmax(rbeta(80, 1.8, 3.0), 0.02), 0.95),
  risk_culture = rnorm(80, 0, 0.8)
) |>
  dplyr::mutate(
    public_bank = as.integer(rank(-initial_assets_bn, ties.method = "first") <= 40)
  )

# ---- County cross-section (40 counties) ----------------------
# Counties provide the demand side of the lending market.

counties <- tibble::tibble(
  county_fips = sprintf("%05d", 1001:(1000 + 40)),
  county_name = stringr::str_c("County ", stringr::str_pad(1:40, width = 2, pad = "0")),
  region = sample(regions, 40, replace = TRUE),
  county_fe = rnorm(40, 0, 0.4),
  manufacturing_share = round(runif(40, 0.08, 0.34), 3),
  housing_exposure = round(runif(40, 0.10, 0.90), 3),
  population_index = round(runif(40, 0.50, 1.80), 3)
)

# ---- Macro time series (one row per year) --------------------

year_tbl <- tibble::tibble(
  year = years,
  macro_cycle = c(-0.25, -0.12, 0.05, 0.18, 0.22, 0.20, 0.16, 0.08, -0.12, 0.04, -0.35, 0.10),
  rate_shock = c(0.00, 0.00, 0.02, 0.05, 0.10, 0.12, 0.10, 0.06, 0.08, 0.18, 0.55, 0.25),
  regulatory_intensity = c(0.10, 0.12, 0.15, 0.20, 0.25, 0.28, 0.30, 0.28, 0.32, 0.36, 0.48, 0.40)
)

# ---- County x year: local demand -----------------------------
# Local demand depends on county FE, the macro cycle, housing
# exposure interacted with the rate shock, and manufacturing.

county_year <- tidyr::crossing(counties, year_tbl) |>
  dplyr::mutate(
    local_demand = 0.45 * county_fe +
      0.85 * macro_cycle -
      0.50 * housing_exposure * rate_shock +
      0.15 * manufacturing_share +
      rnorm(dplyr::n(), 0, 0.15)
  )

# ---- Bank-county exposure map --------------------------------
# Each bank lends in 4-7 counties (mostly its own region).
# exposure_weight = share of each county in the bank's portfolio.

exposure_blueprint <- banks |>
  dplyr::transmute(
    bank_id,
    bank_region = region,
    n_counties = sample(4:7, dplyr::n(), replace = TRUE)
  )

bank_county_panel <- purrr::pmap_dfr(
  exposure_blueprint,
  function(bank_id, bank_region, n_counties) {
    same_region <- counties |>
      dplyr::filter(region == bank_region) |>
      dplyr::pull(county_fips)

    other_region <- counties |>
      dplyr::filter(region != bank_region) |>
      dplyr::pull(county_fips)

    n_same <- min(length(same_region), max(3L, n_counties - 1L))
    n_other <- min(length(other_region), max(0L, n_counties - n_same))

    selected <- c(
      sample(same_region, n_same, replace = FALSE),
      if (n_other > 0) sample(other_region, n_other, replace = FALSE) else character(0)
    )

    weights <- stats::rgamma(length(selected), shape = 3, rate = 1)

    tibble::tibble(
      bank_id = bank_id,
      county_fips = selected,
      exposure_weight = weights / sum(weights)
    )
  }
)

# ---- Weighted local demand per bank-year ---------------------
# Aggregates county-level demand using the bank's exposure map.
# This is the demand-side shifter that creates endogeneity in
# observed loan_growth: it conflates supply and demand.

weighted_demand <- bank_county_panel |>
  dplyr::left_join(
    county_year |>
      dplyr::select(county_fips, year, local_demand),
    by = "county_fips",
    relationship = "many-to-many"
  ) |>
  dplyr::group_by(bank_id, year) |>
  dplyr::summarise(
    weighted_local_demand = sum(exposure_weight * local_demand),
    n_counties = dplyr::n_distinct(county_fips),
    .groups = "drop"
  )

# ---- Master bank x year panel --------------------------------
# Key variables:
#   treated            – 1 once assets cross the 10 bn threshold
#   fragility_iv       – instrument: predetermined securities_exposure
#                        x aggregate rate_shock
#   loan_growth        – observed outcome (supply + demand mixed)
#   latent_credit_supply – true supply (unobserved in practice)

bank_year <- tidyr::crossing(bank_id = banks$bank_id, year = years) |>
  dplyr::left_join(banks, by = "bank_id") |>
  dplyr::left_join(year_tbl, by = "year") |>
  dplyr::left_join(weighted_demand, by = c("bank_id", "year")) |>
  dplyr::group_by(bank_id) |>
  dplyr::arrange(year, .by_group = TRUE) |>
  dplyr::mutate(
    size_shock = rnorm(dplyr::n(), 0, 0.025),
    asset_growth = pmin(
      pmax(0.055 + 0.02 * weighted_local_demand + 0.015 * bank_fe + size_shock, -0.04),
      0.18
    ),
    assets_bn = initial_assets_bn * cumprod(1 + asset_growth),
    log_assets = log(assets_bn),
    first_treat = {
      crossing_years <- year[assets_bn >= 10]
      if (length(crossing_years) == 0) 0L else min(crossing_years)
    },
    treated = as.integer(first_treat > 0 & year >= first_treat),
    event_time = dplyr::if_else(first_treat > 0, year - first_treat, NA_integer_),
    fragility_iv = securities_exposure * rate_shock,
    risk_index = 0.60 * securities_exposure +
      0.50 * uninsured_share +
      0.25 * pmax(-weighted_local_demand, 0) +
      0.15 * pmax(-bank_fe, 0) +
      0.10 * (risk_culture > 0),
    capital_ratio = pmin(
      pmax(
        capital_base +
          0.012 * weighted_local_demand -
          0.020 * fragility_iv -
          0.010 * treated * regulatory_intensity +
          0.006 * political_connection +
          rnorm(dplyr::n(), 0, 0.006),
        0.06
      ),
      0.20
    ),
    liquidity_ratio = pmin(
      pmax(
        liquidity_base +
          0.008 * weighted_local_demand -
          0.015 * uninsured_share * rate_shock -
          0.005 * treated +
          rnorm(dplyr::n(), 0, 0.008),
        0.05
      ),
      0.35
    ),
    latent_credit_supply = 0.015 +
      0.20 * capital_ratio +
      0.10 * liquidity_ratio -
      0.090 * fragility_iv -
      0.035 * treated * regulatory_intensity +
      0.018 * political_connection * treated +
      0.015 * bank_fe +
      rnorm(dplyr::n(), 0, 0.012),
    loan_growth = latent_credit_supply +
      0.32 * weighted_local_demand +
      rnorm(dplyr::n(), 0, 0.015),
    small_business_share = pmin(
      pmax(
        0.22 +
          0.18 * capital_ratio -
          0.025 * treated +
          0.012 * political_connection +
          rnorm(dplyr::n(), 0, 0.02),
        0.05
      ),
      0.55
    ),
    chargeoff_rate = pmin(
      pmax(
        0.010 +
          0.03 * risk_index -
          0.02 * capital_ratio +
          0.01 * rate_shock +
          rnorm(dplyr::n(), 0, 0.004),
        0.001
      ),
      0.08
    ),
    roa = 0.007 +
      0.04 * capital_ratio +
      0.02 * weighted_local_demand -
      0.06 * chargeoff_rate +
      rnorm(dplyr::n(), 0, 0.003)
  ) |>
  dplyr::ungroup()

# ---- Data dictionary -----------------------------------------

data_dictionary <- tibble::tribble(
  ~object, ~variable, ~definition, ~economic_role,
  "master_bank_panel", "bank_id", "Synthetic bank identifier", "Panel identifier",
  "master_bank_panel", "year", "Calendar year", "Time identifier",
  "master_bank_panel", "assets_bn", "Total bank assets in USD billions", "Bank size and threshold running variable",
  "master_bank_panel", "weighted_local_demand", "Exposure-weighted local demand for each bank-year", "Captures demand conditions in the bank's footprint",
  "master_bank_panel", "capital_ratio", "Equity capital over assets", "Bank resilience and lending capacity",
  "master_bank_panel", "liquidity_ratio", "Liquid assets over assets", "Funding flexibility",
  "master_bank_panel", "loan_growth", "Observed annual loan growth", "Baseline lending outcome",
  "master_bank_panel", "treated", "Indicator for being above the regulatory threshold after first crossing", "Threshold treatment status",
  "master_bank_panel", "first_treat", "First year the bank crosses the size threshold", "Treatment timing",
  "master_bank_panel", "event_time", "Years relative to first threshold crossing", "Useful for later dynamic designs",
  "master_bank_panel", "small_business_share", "Share of lending directed to small business credit", "Alternative lending outcome",
  "master_bank_panel", "chargeoff_rate", "Loan charge-offs over assets", "Portfolio risk measure",
  "master_bank_panel", "roa", "Return on assets", "Bank performance outcome",
  "bank_county_panel", "exposure_weight", "Share of the bank's lending footprint in a county", "Weight used to aggregate county demand to the bank level"
)

# ---- Save everything -----------------------------------------

save_rds_finance4(banks, "data/banks.rds")
save_rds_finance4(counties, "data/counties.rds")
save_rds_finance4(bank_year, "data/master_bank_panel.rds")
save_rds_finance4(bank_county_panel, "data/bank_county_panel.rds")

write_csv_finance4(bank_year, "data/master_bank_panel.csv")
write_csv_finance4(bank_county_panel, "data/bank_county_panel.csv")
write_csv_finance4(data_dictionary, "data/data_dictionary.csv")

write_text_finance4(
  c(
    "TA1 teaching data were built successfully.",
    paste("Banks:", nrow(banks)),
    paste("Counties:", nrow(counties)),
    paste("Years:", min(years), "-", max(years)),
    paste("Share ever treated:", round(mean(dplyr::distinct(bank_year, bank_id, first_treat)$first_treat > 0), 3))
  ),
  "output/text/data_build_summary.txt"
)
