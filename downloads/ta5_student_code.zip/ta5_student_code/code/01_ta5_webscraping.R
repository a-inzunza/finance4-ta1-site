# ==============================================================================
#  TA5 — Other methods: web scraping for financial research (student edition)
# ==============================================================================
#
#  Empirical question:
#    What can we learn about the largest US banks by scraping public web data,
#    and how do we do it safely, ethically, and reproducibly?
#
#  How this package is wired:
#    - All raw HTML is shipped under data/raw_wikipedia/ so that the script
#      always runs offline. The first time you run it with internet, the cache
#      will refresh as needed; otherwise it reads from disk.
#    - Set REFRESH_CACHE <- TRUE if you want to force a fresh scrape.
# ==============================================================================

source("code/00_utils.R")
load_finance4_packages()

REFRESH_CACHE <- FALSE

ensure_dir("data/raw_wikipedia")
ensure_dir("data/raw_wikipedia/banks")
ensure_dir("output/tables")
ensure_dir("output/figures")
ensure_dir("output/text")

# ------------------------------------------------------------------------------
#  SECTION 1 — ETHICS AND HOUSEKEEPING
# ------------------------------------------------------------------------------

robots_url <- "https://en.wikipedia.org/robots.txt"
robots_cache <- "data/raw_wikipedia/robots.txt"

robots_lines <- fetch_or_cache_text(robots_url, robots_cache,
                                    refresh = REFRESH_CACHE)

robots_relevant <- robots_lines[grepl("User-agent|Disallow|Allow|Crawl-delay",
                                      robots_lines, ignore.case = TRUE)]

ethics_log <- c(
  "TA5 polite-scraping log",
  paste0("Built on: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("User-Agent sent: ", finance4_user_agent()),
  paste0("Robots.txt cached at: ", robots_cache),
  "First robots.txt directives we matched:",
  utils::head(robots_relevant, 25)
)

write_text_finance4(ethics_log, "output/text/ta5_ethics_log.txt")

# ------------------------------------------------------------------------------
#  SECTION 2 — STATIC SCRAPING WITH rvest: WIKIPEDIA TABLE OF LARGEST US BANKS
# ------------------------------------------------------------------------------

list_url <- "https://en.wikipedia.org/wiki/List_of_largest_banks_in_the_United_States"
list_cache <- "data/raw_wikipedia/list_of_largest_banks.html"

list_html <- fetch_or_cache(list_url, list_cache, refresh = REFRESH_CACHE)

wiki_tables <- list_html |>
  rvest::html_elements("table.wikitable") |>
  rvest::html_table(fill = TRUE)

stopifnot(length(wiki_tables) >= 1L)

raw_bank_table <- wiki_tables[[1]]

clean_colnames <- function(x) {
  x |>
    stringr::str_to_lower() |>
    stringr::str_replace_all("[^a-z0-9]+", "_") |>
    stringr::str_remove_all("^_|_$")
}

names(raw_bank_table) <- clean_colnames(names(raw_bank_table))

rank_col <- intersect(c("rank", "no", "no_"), names(raw_bank_table))[1]
name_col <- intersect(c("bank_name", "bank", "name"), names(raw_bank_table))[1]
hq_col   <- intersect(c("headquarters", "hq", "city"), names(raw_bank_table))[1]
asset_col <- names(raw_bank_table)[
  grepl("asset", names(raw_bank_table)) & !grepl("change", names(raw_bank_table))
][1]

stopifnot(!is.na(name_col), !is.na(asset_col))

extract_first_number <- function(x) {
  cleaned <- stringr::str_replace_all(as.character(x), "[\\$,]", "")
  cleaned <- stringr::str_extract(cleaned, "[0-9]+(?:\\.[0-9]+)?")
  as.numeric(cleaned)
}

bank_table <- tibble::tibble(
  rank = if (!is.na(rank_col)) extract_first_number(raw_bank_table[[rank_col]]) else seq_len(nrow(raw_bank_table)),
  bank_name = stringr::str_trim(as.character(raw_bank_table[[name_col]])),
  headquarters = if (!is.na(hq_col)) stringr::str_trim(as.character(raw_bank_table[[hq_col]])) else NA_character_,
  total_assets_usd_bn = extract_first_number(raw_bank_table[[asset_col]])
) |>
  dplyr::filter(
    !is.na(bank_name),
    nchar(bank_name) > 0,
    !is.na(total_assets_usd_bn)
  ) |>
  dplyr::arrange(rank)

top_banks <- bank_table |>
  dplyr::slice_head(n = 15)

write_csv_finance4(top_banks, "output/tables/ta5_top_banks.csv")

asset_plot <- top_banks |>
  dplyr::mutate(bank_name = factor(bank_name, levels = rev(bank_name))) |>
  ggplot2::ggplot(ggplot2::aes(x = total_assets_usd_bn, y = bank_name)) +
  ggplot2::geom_col(fill = "#3b6fab", alpha = 0.9) +
  ggplot2::labs(
    title = "Largest US banks by total assets",
    subtitle = "Source: Wikipedia, scraped via rvest",
    x = "Total assets (US$ billion)",
    y = NULL
  ) +
  theme_finance4()

save_plot_finance4(asset_plot, "output/figures/ta5_top_banks.png", height = 6)

# ------------------------------------------------------------------------------
#  SECTION 3 — FOLLOWING LINKS: ONE WIKIPEDIA PAGE PER BANK
# ------------------------------------------------------------------------------

table_node <- list_html |>
  rvest::html_elements("table.wikitable") |>
  utils::head(1)

bank_links <- table_node |>
  rvest::html_elements("tr") |>
  purrr::map(function(row) {
    cells <- rvest::html_elements(row, "td, th")
    if (length(cells) < 2) return(NULL)
    link <- rvest::html_element(cells[2], "a")
    if (is.null(link) || length(link) == 0) return(NULL)
    href <- rvest::html_attr(link, "href")
    text <- rvest::html_text2(link)
    if (is.na(href) || nchar(href) == 0) return(NULL)
    tibble::tibble(
      bank_name_link = stringr::str_trim(text),
      relative_url = href
    )
  }) |>
  purrr::compact() |>
  dplyr::bind_rows() |>
  dplyr::mutate(
    article_url = dplyr::if_else(
      stringr::str_starts(relative_url, "http"),
      relative_url,
      paste0("https://en.wikipedia.org", relative_url)
    )
  ) |>
  dplyr::distinct(bank_name_link, .keep_all = TRUE)

slugify <- function(x) {
  x |>
    stringr::str_to_lower() |>
    stringr::str_replace_all("&", "and") |>
    stringr::str_replace_all("[^a-z0-9]+", "_") |>
    stringr::str_remove_all("^_|_$")
}

top_banks_with_url <- top_banks |>
  dplyr::mutate(slug = slugify(bank_name)) |>
  dplyr::left_join(
    bank_links |> dplyr::mutate(slug = slugify(bank_name_link)),
    by = "slug"
  ) |>
  dplyr::filter(!is.na(article_url))

extract_lead_text <- function(article_html, max_paragraphs = 3) {
  paragraphs <- article_html |>
    rvest::html_elements("div.mw-parser-output > p") |>
    rvest::html_text2()
  paragraphs <- paragraphs[nchar(stringr::str_trim(paragraphs)) > 80]
  paragraphs <- utils::head(paragraphs, max_paragraphs)
  paste(paragraphs, collapse = " ")
}

bank_corpus <- top_banks_with_url |>
  dplyr::mutate(
    cache_path = file.path(
      "data/raw_wikipedia/banks", paste0(slug, ".html")
    ),
    article_html = purrr::map2(
      article_url,
      cache_path,
      ~ fetch_or_cache(.x, .y, refresh = REFRESH_CACHE)
    ),
    lead_text = purrr::map_chr(article_html, extract_lead_text)
  ) |>
  dplyr::select(rank, bank_name, headquarters, total_assets_usd_bn,
                article_url, lead_text)

write_csv_finance4(
  bank_corpus |> dplyr::select(-lead_text),
  "output/tables/ta5_bank_links.csv"
)

trim_text <- function(x, n_chars = 600) {
  x <- stringr::str_replace_all(x, "\\s+", " ")
  trimmed <- stringr::str_sub(x, 1, n_chars)
  ifelse(nchar(x) > n_chars, paste0(trimmed, "..."), trimmed)
}

corpus_for_display <- bank_corpus |>
  dplyr::transmute(
    rank,
    bank_name,
    excerpt = trim_text(lead_text)
  )

write_csv_finance4(corpus_for_display, "output/tables/ta5_corpus_excerpts.csv")

# ------------------------------------------------------------------------------
#  SECTION 4 — DYNAMIC CONTENT (CONCEPTUAL)
# ------------------------------------------------------------------------------

dynamic_snippet <- c(
  "# Pseudocode: scraping a JavaScript-rendered page with chromote",
  "library(chromote)",
  "b <- ChromoteSession$new()",
  'b$Page$navigate("https://example.com/dashboard")',
  "b$Page$loadEventFired()",
  "rendered <- b$DOM$getDocument() |>",
  '  purrr::pluck("root", "nodeId") |>',
  "  (\\(id) b$DOM$getOuterHTML(nodeId = id))() |>",
  '  purrr::pluck("outerHTML")',
  "b$close()",
  "parsed <- xml2::read_html(rendered)"
)

write_text_finance4(dynamic_snippet, "output/text/ta5_chromote_snippet.R")

# ------------------------------------------------------------------------------
#  SECTION 5 — TOKENISATION AND BANK-LEVEL TERM FREQUENCIES
# ------------------------------------------------------------------------------

custom_stopwords <- tibble::tibble(
  word = c(
    "bank", "banks", "banking", "company", "corporation", "inc", "incorporated",
    "based", "headquartered", "american", "u.s", "united", "states", "u.s.a",
    "wikipedia", "company's", "billion", "trillion", "million", "th",
    "largest", "largest's", "world", "new", "york"
  ),
  lexicon = "finance4-custom"
)

stopword_table <- dplyr::bind_rows(
  tidytext::stop_words,
  custom_stopwords
)

tokens <- bank_corpus |>
  dplyr::select(rank, bank_name, lead_text) |>
  tidytext::unnest_tokens(word, lead_text, token = "words") |>
  dplyr::mutate(word = stringr::str_remove_all(word, "[^a-z']")) |>
  dplyr::filter(nchar(word) > 2) |>
  dplyr::anti_join(stopword_table, by = "word")

token_corpus_summary <- tokens |>
  dplyr::summarise(
    n_banks = dplyr::n_distinct(bank_name),
    n_tokens = dplyr::n(),
    n_unique_words = dplyr::n_distinct(word)
  )

write_csv_finance4(token_corpus_summary, "output/tables/ta5_corpus_summary.csv")

term_freq_overall <- tokens |>
  dplyr::count(word, sort = TRUE, name = "freq") |>
  dplyr::slice_head(n = 25)

write_csv_finance4(term_freq_overall, "output/tables/ta5_top_terms.csv")

top_terms_per_bank <- tokens |>
  dplyr::count(bank_name, word, name = "freq") |>
  dplyr::group_by(bank_name) |>
  dplyr::slice_max(order_by = freq, n = 3, with_ties = FALSE) |>
  dplyr::ungroup() |>
  dplyr::arrange(bank_name, dplyr::desc(freq))

write_csv_finance4(top_terms_per_bank, "output/tables/ta5_top_terms_per_bank.csv")

top_terms_plot <- term_freq_overall |>
  dplyr::mutate(word = factor(word, levels = rev(word))) |>
  ggplot2::ggplot(ggplot2::aes(x = freq, y = word)) +
  ggplot2::geom_col(fill = "#a85738", alpha = 0.9) +
  ggplot2::labs(
    title = "Top 25 words across the scraped Wikipedia corpus",
    subtitle = "After removing English stopwords and a small custom list",
    x = "Frequency",
    y = NULL
  ) +
  theme_finance4()

save_plot_finance4(top_terms_plot, "output/figures/ta5_top_terms.png", height = 6)

# ------------------------------------------------------------------------------
#  SECTION 6 — A SIMPLE FINANCE TONE SCORE
# ------------------------------------------------------------------------------

tone_dict <- finance4_tone_dictionary()

tone_matches <- tokens |>
  dplyr::inner_join(tone_dict, by = "word")

tone_scores <- tokens |>
  dplyr::group_by(rank, bank_name) |>
  dplyr::summarise(total_tokens = dplyr::n(), .groups = "drop") |>
  dplyr::left_join(
    tone_matches |>
      dplyr::group_by(bank_name, sentiment) |>
      dplyr::summarise(n = dplyr::n(), .groups = "drop") |>
      tidyr::pivot_wider(
        names_from = sentiment,
        values_from = n,
        values_fill = 0
      ),
    by = "bank_name"
  ) |>
  dplyr::mutate(
    positive = dplyr::coalesce(positive, 0L),
    negative = dplyr::coalesce(negative, 0L),
    tone = (positive - negative) / total_tokens
  ) |>
  dplyr::arrange(rank)

write_csv_finance4(tone_scores, "output/tables/ta5_tone_scores.csv")

tone_plot <- tone_scores |>
  dplyr::mutate(bank_name = factor(bank_name, levels = rev(bank_name))) |>
  ggplot2::ggplot(ggplot2::aes(x = tone, y = bank_name, fill = tone > 0)) +
  ggplot2::geom_col(alpha = 0.9) +
  ggplot2::scale_fill_manual(
    values = c("TRUE" = "#3b6fab", "FALSE" = "#a85738"),
    guide = "none"
  ) +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed") +
  ggplot2::labs(
    title = "Finance tone score by bank",
    subtitle = "Tone = (positive - negative dictionary matches) / total tokens",
    x = "Tone (positive minus negative, normalised)",
    y = NULL
  ) +
  theme_finance4()

save_plot_finance4(tone_plot, "output/figures/ta5_tone_by_bank.png", height = 6)

# ------------------------------------------------------------------------------
#  SECTION 7 — LATEX EXPORTS
# ------------------------------------------------------------------------------

top_banks_latex <- knitr::kable(
  top_banks |>
    dplyr::transmute(
      Rank = rank,
      Bank = bank_name,
      Headquarters = headquarters,
      `Total assets (US\\$bn)` = format(round(total_assets_usd_bn, 1), big.mark = ",")
    ),
  format = "latex",
  booktabs = TRUE,
  caption = "Largest US banks by total assets (Wikipedia, scraped)."
)

write_tex_finance4(top_banks_latex, "output/tables/ta5_top_banks.tex")

tone_latex <- knitr::kable(
  tone_scores |>
    dplyr::transmute(
      Rank = rank,
      Bank = bank_name,
      `Total tokens` = total_tokens,
      Positive = positive,
      Negative = negative,
      Tone = round(tone, 4)
    ),
  format = "latex",
  booktabs = TRUE,
  caption = "Finance tone score per bank from scraped Wikipedia text."
)

write_tex_finance4(tone_latex, "output/tables/ta5_tone_scores.tex")

# ------------------------------------------------------------------------------
#  SECTION 8 — TEACHING NOTE
# ------------------------------------------------------------------------------

teaching_note <- c(
  "TA5 — Web scraping for financial research (student edition)",
  "",
  "What the script does:",
  paste0(
    "  1. Sends a User-Agent header identifying us, ",
    "throttled to one request per second."
  ),
  "  2. Caches every response under data/raw_wikipedia/.",
  "  3. Parses the Wikipedia table of largest US banks with rvest.",
  "  4. Follows links to each bank's Wikipedia article and stores the lead text.",
  "  5. Tokenises the corpus, computes term frequencies, and scores tone.",
  "  6. Saves tables, figures, and LaTeX exports under output/.",
  "",
  paste0("Banks scraped: ", nrow(bank_corpus)),
  paste0("Tokens analysed: ", token_corpus_summary$n_tokens),
  paste0("Unique words: ", token_corpus_summary$n_unique_words)
)

write_text_finance4(teaching_note, "output/text/ta5_note.txt")
