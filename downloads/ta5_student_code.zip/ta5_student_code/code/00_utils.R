required_packages <- c(
  "dplyr",
  "ggplot2",
  "httr2",
  "knitr",
  "purrr",
  "readr",
  "rvest",
  "stringr",
  "tibble",
  "tidyr",
  "tidytext",
  "xml2"
)

load_finance4_packages <- function() {
  missing_packages <- required_packages[
    !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  ]

  if (length(missing_packages) > 0) {
    stop(
      paste(
        "Missing packages:",
        paste(missing_packages, collapse = ", "),
        "\nInstall them with install.packages() before running TA5."
      ),
      call. = FALSE
    )
  }

  invisible(lapply(required_packages, library, character.only = TRUE))
}

ensure_dir <- function(path) {
  if (!dir.exists(path)) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
}

theme_finance4 <- function() {
  ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", color = "#1f2733"),
      plot.subtitle = ggplot2::element_text(color = "#5a6573"),
      axis.title = ggplot2::element_text(color = "#1f2733"),
      axis.text = ggplot2::element_text(color = "#44505e"),
      panel.grid.minor = ggplot2::element_blank(),
      legend.position = "bottom",
      legend.title = ggplot2::element_blank()
    )
}

save_plot_finance4 <- function(plot, path, width = 8, height = 5, dpi = 300) {
  ensure_dir(dirname(path))
  ggplot2::ggsave(filename = path, plot = plot, width = width, height = height, dpi = dpi)
}

write_csv_finance4 <- function(data, path) {
  ensure_dir(dirname(path))
  readr::write_csv(data, path)
}

write_text_finance4 <- function(lines, path) {
  ensure_dir(dirname(path))
  writeLines(lines, path)
}

write_tex_finance4 <- function(tex_string, path) {
  ensure_dir(dirname(path))
  writeLines(as.character(tex_string), path)
}

#' Identify ourselves to the server. Replace the email below with your own.
finance4_user_agent <- function() {
  paste0(
    "Finance4-TA5-educational-scraper/1.0 ",
    "(Bocconi PhD teaching assistant; ",
    "alejandra.inzunza@phd.unibocconi.it)"
  )
}

#' One polite HTTP GET with throttle, identifiable User-Agent, and retries.
polite_get <- function(url, throttle = 1) {
  Sys.sleep(throttle)
  httr2::request(url) |>
    httr2::req_user_agent(finance4_user_agent()) |>
    httr2::req_retry(max_tries = 3, backoff = ~ 2L) |>
    httr2::req_perform()
}

#' Fetch a URL with a disk cache. If the cache exists we use it; otherwise we
#' do a polite GET, save the body, and return the parsed HTML.
fetch_or_cache <- function(url, cache_path, refresh = FALSE) {
  ensure_dir(dirname(cache_path))

  if (file.exists(cache_path) && !refresh) {
    return(xml2::read_html(cache_path, encoding = "UTF-8"))
  }

  resp <- tryCatch(polite_get(url), error = function(e) e)

  if (inherits(resp, "error")) {
    if (file.exists(cache_path)) {
      message("[scrape] network failed, using cache: ", cache_path)
      return(xml2::read_html(cache_path, encoding = "UTF-8"))
    }
    stop(
      "Could not fetch ", url, " and no cache exists at ", cache_path,
      ".\nReason: ", conditionMessage(resp),
      call. = FALSE
    )
  }

  body <- httr2::resp_body_string(resp)
  writeLines(body, cache_path, useBytes = TRUE)
  xml2::read_html(cache_path, encoding = "UTF-8")
}

#' Same as fetch_or_cache() but returns plain text — used for robots.txt.
fetch_or_cache_text <- function(url, cache_path, refresh = FALSE) {
  ensure_dir(dirname(cache_path))

  if (file.exists(cache_path) && !refresh) {
    return(readLines(cache_path, warn = FALSE, encoding = "UTF-8"))
  }

  resp <- tryCatch(polite_get(url), error = function(e) e)

  if (inherits(resp, "error")) {
    if (file.exists(cache_path)) {
      message("[scrape] network failed, using cache: ", cache_path)
      return(readLines(cache_path, warn = FALSE, encoding = "UTF-8"))
    }
    stop(
      "Could not fetch ", url, " and no cache exists at ", cache_path,
      ".\nReason: ", conditionMessage(resp),
      call. = FALSE
    )
  }

  body <- httr2::resp_body_string(resp)
  writeLines(body, cache_path, useBytes = TRUE)
  readLines(cache_path, warn = FALSE, encoding = "UTF-8")
}

#' Small, transparent finance tone dictionary.
finance4_tone_dictionary <- function() {
  tibble::tibble(
    word = c(
      "growth", "profitable", "strong", "stable", "robust", "expansion",
      "innovative", "leading", "premier", "successful", "resilient",
      "well-capitalized", "prudent", "diversified", "investment",
      "loss", "losses", "failed", "failure", "bankrupt", "bankruptcy",
      "decline", "declined", "risk", "risks", "concern", "concerns",
      "stress", "downgrade", "downgraded", "litigation", "fraud",
      "scandal", "fine", "fined", "penalty", "settlement", "recession"
    ),
    sentiment = c(
      rep("positive", 15),
      rep("negative", 23)
    )
  )
}
