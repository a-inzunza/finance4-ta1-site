# Finance 4 TA5 Student Code

This folder is the **student-facing TA5 package** on web scraping. It is separate from the website source on purpose.

## What students should do

1. Open `Finance4_TA5_Student.Rproj` in RStudio.
2. Open `main.R`.
3. Run:

```r
source("main.R")
```

That script will:

- read (or, if you have internet, refresh) the cached HTML under `data/raw_wikipedia/`,
- scrape the Wikipedia table of the largest US banks with `rvest`,
- follow links to each bank's article and assemble a small text corpus,
- run tokenisation, term-frequency analysis, and a transparent finance tone score,
- export figures, tables, and LaTeX files to `output/`.

## Online vs offline

The package ships with a complete cached snapshot of every page used. You can run it without an internet connection and it will produce identical outputs.

If you want a fresh scrape (for example to see this term's bank rankings), open `code/01_ta5_webscraping.R` and set:

```r
REFRESH_CACHE <- TRUE
```

The script throttles to one request per second and sends a meaningful `User-Agent` header. Update the User-Agent in `code/00_utils.R` to include your own contact email before running a live scrape.

## What is inside

```text
ta5_student_code/
  code/
    00_utils.R
    01_ta5_webscraping.R
  data/
    raw_wikipedia/
      list_of_largest_banks.html
      robots.txt
      banks/<one HTML file per bank>
  Finance4_TA5_Student.Rproj
  main.R
  run_ta5.R
```

## Output files

After running the code you should see:

- `output/text/ta5_ethics_log.txt`
- `output/text/ta5_chromote_snippet.R`
- `output/text/ta5_note.txt`
- `output/tables/ta5_top_banks.csv`
- `output/tables/ta5_top_banks.tex`
- `output/tables/ta5_bank_links.csv`
- `output/tables/ta5_corpus_excerpts.csv`
- `output/tables/ta5_corpus_summary.csv`
- `output/tables/ta5_top_terms.csv`
- `output/tables/ta5_top_terms_per_bank.csv`
- `output/tables/ta5_tone_scores.csv`
- `output/tables/ta5_tone_scores.tex`
- `output/figures/ta5_top_banks.png`
- `output/figures/ta5_top_terms.png`
- `output/figures/ta5_tone_by_bank.png`

## Packages

The TA5 package expects these packages to be installed:

- `dplyr`
- `ggplot2`
- `httr2`
- `knitr`
- `purrr`
- `readr`
- `rvest`
- `stringr`
- `tibble`
- `tidyr`
- `tidytext`
- `xml2`

If a package is missing, the script will stop and tell you which one to install.

## Polite-scraping checklist

Before you scrape any new source on your own, walk through this list:

1. Is there an API? If yes, use it.
2. Is the site's `robots.txt` permissive for the path you want?
3. Have you set a real, contactable `User-Agent`?
4. Are you throttling to ≤ 1 request per second?
5. Are you caching the responses on disk so you do not hit the server twice for the same page?
6. Are you respecting the licence and the Terms of Service?
7. If the data contains personal information, do you have a lawful basis under GDPR (or your local equivalent)?

Get all seven yeses before you press Run.
