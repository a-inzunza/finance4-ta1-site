get_run_ta3_path <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_matches <- grep("^--file=", cmd_args, value = TRUE)

  if (length(file_matches) > 0) {
    return(
      normalizePath(
        sub("^--file=", "", file_matches[length(file_matches)]),
        winslash = "/",
        mustWork = TRUE
      )
    )
  }

  frame_files <- vapply(
    sys.frames(),
    function(frame) {
      ofile <- frame$ofile
      if (is.null(ofile)) "" else ofile
    },
    character(1)
  )

  frame_files <- frame_files[nzchar(frame_files)]

  if (length(frame_files) > 0) {
    return(normalizePath(frame_files[length(frame_files)], winslash = "/", mustWork = TRUE))
  }

  stop(
    "Could not determine the location of run_ta3.R. ",
    "Either set the working directory to the TA3 student folder and source('run_ta3.R'), ",
    "or source the file using an absolute path.",
    call. = FALSE
  )
}

original_wd <- getwd()
on.exit(setwd(original_wd), add = TRUE)

project_root <- dirname(get_run_ta3_path())
setwd(project_root)

source("code/01_build_ta3_data.R")
source("code/02_ta3_iv_credit_supply.R")

message("TA3 student outputs created successfully in: ", normalizePath("output", winslash = "/"))
