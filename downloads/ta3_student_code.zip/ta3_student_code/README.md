# Finance 4 TA3 Student Code

This folder is the **student-facing TA3 package**. It is separate from the website source on purpose.

## What students should do

1. Open `Finance4_TA3_Student.Rproj`
2. Open `main.R`
3. Run:

```r
source("main.R")
```

That script will:

- build a compact synthetic county-level IV dataset,
- run the TA3 IV analysis,
- export LaTeX tables to `output/tables/`,
- save figures, tables, and model outputs into `output/`.

## What is inside

```text
ta3_student_code/
  code/
    00_utils.R
    01_build_ta3_data.R
    02_ta3_iv_credit_supply.R
  Finance4_TA3_Student.Rproj
  main.R
  run_ta3.R
```

## Output files

After running the code, students should find:

- `data/county_panel.rds`
- `data/county_panel.csv`
- `data/data_dictionary.csv`
- `output/figures/ta3_ols_scatter.png`
- `output/figures/ta3_first_stage.png`
- `output/figures/ta3_ols_vs_iv.png`
- `output/tables/ta3_data_summary.csv`
- `output/tables/ta3_design_summary.csv`
- `output/tables/ta3_design_summary.tex`
- `output/tables/ta3_model_table.csv`
- `output/tables/ta3_main_result_summary.csv`
- `output/tables/ta3_regression.tex`
- `output/models/ta3_models.rds`
- `output/text/ta3_note.txt`

## Packages

The TA3 package expects these packages to be installed:

- `broom`
- `dplyr`
- `fixest`
- `ggplot2`
- `knitr`
- `kableExtra`
- `purrr`
- `readr`
- `stringr`
- `tidyr`

If a package is missing, the script will stop and tell the student which one to install.
