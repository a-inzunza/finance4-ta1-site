source("code/00_utils.R")
load_finance4_packages()

# ============================================================
#  FINANCE 4 — TA SESSION 3
#  Script 02: Instrumental variables and local credit supply
# ------------------------------------------------------------
#  Main teaching question:
#
#  What is the causal effect of local bank credit supply on
#  county employment growth?
# ============================================================

county_panel <- readRDS("data/county_panel.rds")


# ############################################################
# SECTION 1 — DATA SUMMARY
# ############################################################

ta3_data_summary <- county_panel |>
  dplyr::summarise(
    n_county_year = dplyr::n(),
    n_counties = dplyr::n_distinct(county_fips),
    first_year = min(year),
    last_year = max(year),
    mean_observed_credit_growth = mean(observed_credit_growth),
    mean_employment_growth = mean(employment_growth),
    mean_instrument_z = mean(instrument_z)
  )

design_summary <- county_panel |>
  dplyr::mutate(
    exposure_group = dplyr::if_else(
      instrument_z >= stats::median(instrument_z),
      "High instrument exposure",
      "Low instrument exposure"
    )
  ) |>
  dplyr::group_by(exposure_group) |>
  dplyr::summarise(
    mean_observed_credit_growth = mean(observed_credit_growth),
    mean_county_credit_supply = mean(county_credit_supply),
    mean_employment_growth = mean(employment_growth),
    mean_local_demand = mean(local_demand),
    .groups = "drop"
  )


# ############################################################
# SECTION 2 — OLS
# ############################################################
# OLS is biased because local demand affects both employment and
# observed credit growth.

ols_model <- fixest::feols(
  employment_growth ~ observed_credit_growth | county_fips + year,
  cluster = ~county_fips,
  data = county_panel
)


# ############################################################
# SECTION 3 — FIRST STAGE
# ############################################################

first_stage_model <- fixest::feols(
  observed_credit_growth ~ instrument_z | county_fips + year,
  cluster = ~county_fips,
  data = county_panel
)


# ############################################################
# SECTION 4 — REDUCED FORM
# ############################################################

reduced_form_model <- fixest::feols(
  employment_growth ~ instrument_z | county_fips + year,
  cluster = ~county_fips,
  data = county_panel
)


# ############################################################
# SECTION 5 — 2SLS
# ############################################################

iv_model <- fixest::feols(
  employment_growth ~ 1 | county_fips + year | observed_credit_growth ~ instrument_z,
  cluster = ~county_fips,
  data = county_panel
)


# ############################################################
# SECTION 6 — ORDERED RESULTS
# ############################################################

ta3_models <- list(
  OLS = ols_model,
  `First stage` = first_stage_model,
  `Reduced form` = reduced_form_model,
  `2SLS` = iv_model
)

ta3_model_table <- dplyr::bind_rows(
  broom::tidy(ols_model) |> dplyr::mutate(model = "OLS"),
  broom::tidy(first_stage_model) |> dplyr::mutate(model = "First stage"),
  broom::tidy(reduced_form_model) |> dplyr::mutate(model = "Reduced form"),
  broom::tidy(iv_model) |> dplyr::mutate(model = "2SLS")
) |>
  dplyr::mutate(
    model = factor(model, levels = c("OLS", "First stage", "Reduced form", "2SLS"))
  ) |>
  dplyr::arrange(model) |>
  dplyr::select(model, dplyr::everything())

main_result_summary <- tibble::tribble(
  ~step, ~estimand, ~model_name, ~term_name,
  1, "Naive correlation between local credit growth and employment growth", "OLS", "observed_credit_growth",
  2, "Effect of the instrument on local credit growth", "First stage", "instrument_z",
  3, "Effect of the instrument on employment growth", "Reduced form", "instrument_z",
  4, "Causal effect of local credit supply on employment growth", "2SLS", "fit_observed_credit_growth"
) |>
  dplyr::left_join(
    ta3_model_table |>
      dplyr::select(model, term, estimate, std.error, statistic, p.value),
    by = c("model_name" = "model", "term_name" = "term")
  ) |>
  dplyr::mutate(
    dplyr::across(c(estimate, std.error, statistic, p.value), ~round(.x, 4))
  )


# ############################################################
# SECTION 7 — FIGURES
# ############################################################

ols_scatter <- ggplot2::ggplot(
  county_panel,
  ggplot2::aes(x = observed_credit_growth, y = employment_growth)
) +
  ggplot2::geom_point(alpha = 0.45, color = "#0f5f54") +
  ggplot2::geom_smooth(method = "lm", se = FALSE, color = "#9a462f", linewidth = 1) +
  ggplot2::labs(
    title = "Naive OLS relationship",
    subtitle = "Observed local credit growth and employment growth move together, but this relationship mixes supply and demand.",
    x = "Observed local credit growth",
    y = "Employment growth"
  ) +
  theme_finance4() +
  ggplot2::theme(text = ggplot2::element_text(family = "LM Roman 10"))

first_stage_plot <- ggplot2::ggplot(
  county_panel,
  ggplot2::aes(x = instrument_z, y = observed_credit_growth)
) +
  ggplot2::geom_point(alpha = 0.45, color = "#0f5f54") +
  ggplot2::geom_smooth(method = "lm", se = FALSE, color = "#9a462f", linewidth = 1) +
  ggplot2::labs(
    title = "First-stage relationship",
    subtitle = "Counties more exposed to fragile banks experience weaker local credit growth.",
    x = "Exposure-weighted bank fragility instrument",
    y = "Observed local credit growth"
  ) +
  theme_finance4() +
  ggplot2::theme(text = ggplot2::element_text(family = "LM Roman 10"))

coef_plot_data <- main_result_summary |>
  dplyr::filter(model_name %in% c("OLS", "2SLS")) |>
  dplyr::mutate(
    model_name = factor(model_name, levels = c("OLS", "2SLS")),
    lower = estimate - 1.96 * std.error,
    upper = estimate + 1.96 * std.error
  )

coef_comparison_plot <- ggplot2::ggplot(
  coef_plot_data,
  ggplot2::aes(x = model_name, y = estimate)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "#6c757d") +
  ggplot2::geom_pointrange(
    ggplot2::aes(ymin = lower, ymax = upper),
    color = "#9a462f",
    linewidth = 0.7
  ) +
  ggplot2::labs(
    title = "OLS versus 2SLS",
    subtitle = "The IV estimate isolates plausibly exogenous credit-supply variation.",
    x = NULL,
    y = "Coefficient on local credit growth"
  ) +
  theme_finance4() +
  ggplot2::theme(text = ggplot2::element_text(family = "LM Roman 10"))


# ############################################################
# SECTION 8 — LATEX EXPORT
# ############################################################

design_latex <- knitr::kable(
  design_summary,
  format = "latex",
  booktabs = TRUE,
  digits = 4,
  caption = "Counties with high and low instrument exposure"
) |>
  kableExtra::kable_styling(
    latex_options = c("hold_position"),
    full_width = FALSE
  )

regression_latex <- fixest::etable(
  ta3_models,
  cluster = ~county_fips,
  tex = TRUE
)


# ############################################################
# SECTION 9 — SAVE OUTPUTS
# ############################################################

save_plot_finance4(ols_scatter, "output/figures/ta3_ols_scatter.png")
save_plot_finance4(first_stage_plot, "output/figures/ta3_first_stage.png")
save_plot_finance4(coef_comparison_plot, "output/figures/ta3_ols_vs_iv.png")
save_rds_finance4(ta3_models, "output/models/ta3_models.rds")

write_csv_finance4(ta3_data_summary, "output/tables/ta3_data_summary.csv")
write_csv_finance4(design_summary, "output/tables/ta3_design_summary.csv")
write_csv_finance4(ta3_model_table, "output/tables/ta3_model_table.csv")
write_csv_finance4(main_result_summary, "output/tables/ta3_main_result_summary.csv")

write_tex_finance4(design_latex, "output/tables/ta3_design_summary.tex")
write_tex_finance4(regression_latex, "output/tables/ta3_regression.tex")

write_text_finance4(
  c(
    "TA3 teaching note",
    "",
    "Research question: what is the causal effect of local bank credit supply on county employment growth?",
    "1. OLS is biased because local demand affects both employment and observed credit growth.",
    "2. The first stage checks whether the instrument moves local credit growth.",
    "3. The reduced form checks whether the instrument also moves employment growth.",
    "4. 2SLS uses only the instrument-driven part of credit growth to estimate a causal effect.",
    "5. Interpretation: the IV estimate is the effect of local credit supply for counties whose lending conditions move because they are more exposed to fragile banks."
  ),
  "output/text/ta3_note.txt"
)
