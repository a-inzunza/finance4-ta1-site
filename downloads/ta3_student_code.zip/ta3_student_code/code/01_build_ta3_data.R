# ============================================================
#  FINANCE 4 — TA SESSION 3
#  Script 01: Build the TA3 IV dataset
# ------------------------------------------------------------
#  This script creates a compact county-year dataset for the IV
#  lesson. The key question is:
#
#  What is the causal effect of local bank credit supply on
#  county employment growth?
#
#  The DGP intentionally makes OLS biased: local demand affects
#  both credit growth and employment. The instrument uses county
#  exposure to fragile banks when a common rate shock hits.
# ============================================================

source("code/00_utils.R")
load_finance4_packages()

set.seed(4404)

ensure_dir("data")
ensure_dir("output/figures")
ensure_dir("output/models")
ensure_dir("output/tables")
ensure_dir("output/text")

years <- 2012:2023
regions <- c("North", "South", "Midwest", "West")

# ---- County fundamentals ------------------------------------

counties <- tibble::tibble(
  county_fips = sprintf("%05d", 1001:(1000 + 40)),
  county_name = stringr::str_c("County ", stringr::str_pad(1:40, width = 2, pad = "0")),
  region = sample(regions, 40, replace = TRUE),
  county_fe = rnorm(40, 0, 0.35),
  manufacturing_share = runif(40, 0.08, 0.34),
  housing_exposure = runif(40, 0.10, 0.90)
)

year_tbl <- tibble::tibble(
  year = years,
  macro_cycle = c(-0.25, -0.12, 0.05, 0.18, 0.22, 0.20, 0.16, 0.08, -0.12, 0.04, -0.35, 0.10),
  rate_shock = c(0.00, 0.00, 0.02, 0.05, 0.10, 0.12, 0.10, 0.06, 0.08, 0.18, 0.55, 0.25)
)

county_year <- tidyr::crossing(counties, year_tbl) |>
  dplyr::mutate(
    local_demand = 0.45 * county_fe +
      0.85 * macro_cycle -
      0.50 * housing_exposure * rate_shock +
      0.15 * manufacturing_share +
      rnorm(dplyr::n(), 0, 0.15)
  )

# ---- Bank exposures -----------------------------------------
# Banks differ in fragility and lend in several counties.

banks <- tibble::tibble(
  bank_id = sprintf("B%03d", 1:60),
  region = sample(regions, 60, replace = TRUE),
  bank_fe = rnorm(60, 0, 0.30),
  securities_exposure = pmin(pmax(stats::rbeta(60, 2.2, 2.8), 0.05), 0.85),
  liquidity_base = pmin(pmax(rnorm(60, 0.18, 0.04), 0.08), 0.32)
)

exposure_blueprint <- banks |>
  dplyr::transmute(
    bank_id,
    bank_region = region,
    n_counties = sample(3:6, dplyr::n(), replace = TRUE)
  )

bank_county_panel <- purrr::pmap_dfr(
  exposure_blueprint,
  function(bank_id, bank_region, n_counties) {
    same_region <- counties |>
      dplyr::filter(region == bank_region) |>
      dplyr::pull(county_fips)

    other_region <- counties |>
      dplyr::filter(region != bank_region) |>
      dplyr::pull(county_fips)

    n_same <- min(length(same_region), max(2L, n_counties - 1L))
    n_other <- min(length(other_region), max(0L, n_counties - n_same))

    selected <- c(
      sample(same_region, n_same, replace = FALSE),
      if (n_other > 0) sample(other_region, n_other, replace = FALSE) else character(0)
    )

    weights <- stats::rgamma(length(selected), shape = 3, rate = 1)

    tibble::tibble(
      bank_id = bank_id,
      county_fips = selected,
      exposure_weight = weights / sum(weights)
    )
  }
)

weighted_demand <- bank_county_panel |>
  dplyr::left_join(
    county_year |>
      dplyr::select(county_fips, year, local_demand),
    by = "county_fips",
    relationship = "many-to-many"
  ) |>
  dplyr::group_by(bank_id, year) |>
  dplyr::summarise(
    weighted_local_demand = sum(exposure_weight * local_demand),
    .groups = "drop"
  )

bank_year <- tidyr::crossing(bank_id = banks$bank_id, year = years) |>
  dplyr::left_join(banks, by = "bank_id") |>
  dplyr::left_join(year_tbl, by = "year") |>
  dplyr::left_join(weighted_demand, by = c("bank_id", "year")) |>
  dplyr::mutate(
    fragility_iv = securities_exposure * rate_shock,
    latent_credit_supply = 0.015 +
      0.10 * liquidity_base -
      0.090 * fragility_iv +
      0.015 * bank_fe +
      rnorm(dplyr::n(), 0, 0.012),
    loan_growth = latent_credit_supply +
      0.32 * weighted_local_demand +
      rnorm(dplyr::n(), 0, 0.015)
  )

bank_county_year <- tidyr::crossing(bank_county_panel, year = years) |>
  dplyr::left_join(
    bank_year |>
      dplyr::select(bank_id, year, latent_credit_supply, loan_growth, fragility_iv),
    by = c("bank_id", "year")
  ) |>
  dplyr::left_join(
    county_year |>
      dplyr::select(county_fips, year, local_demand),
    by = c("county_fips", "year")
  ) |>
  dplyr::mutate(
    county_bank_credit_supply = latent_credit_supply + rnorm(dplyr::n(), 0, 0.008),
    county_bank_loan_growth = loan_growth + 0.18 * local_demand + rnorm(dplyr::n(), 0, 0.010)
  )

# ---- County panel for IV ------------------------------------

county_panel <- bank_county_year |>
  dplyr::group_by(county_fips, year) |>
  dplyr::summarise(
    observed_credit_growth = sum(exposure_weight * county_bank_loan_growth),
    county_credit_supply = sum(exposure_weight * county_bank_credit_supply),
    instrument_z = sum(exposure_weight * fragility_iv),
    .groups = "drop"
  ) |>
  dplyr::left_join(county_year, by = c("county_fips", "year")) |>
  dplyr::mutate(
    employment_growth = 0.010 +
      0.55 * local_demand +
      0.85 * county_credit_supply +
      rnorm(dplyr::n(), 0, 0.012)
  )

data_dictionary <- tibble::tribble(
  ~object, ~variable, ~definition, ~economic_role,
  "county_panel", "observed_credit_growth", "Exposure-weighted local credit growth", "Endogenous regressor in OLS",
  "county_panel", "county_credit_supply", "Underlying local credit supply component", "True supply channel in the DGP",
  "county_panel", "instrument_z", "Exposure to fragile banks hit by the common rate shock", "Instrument for local credit growth",
  "county_panel", "employment_growth", "County employment growth", "Main real outcome",
  "county_panel", "local_demand", "County-specific demand condition", "Omitted variable that biases OLS"
)

save_rds_finance4(county_panel, "data/county_panel.rds")
write_csv_finance4(county_panel, "data/county_panel.csv")
write_csv_finance4(data_dictionary, "data/data_dictionary.csv")

write_text_finance4(
  c(
    "TA3 teaching data were built successfully.",
    paste("County-years:", nrow(county_panel)),
    paste("Counties:", dplyr::n_distinct(county_panel$county_fips)),
    paste("Years:", min(county_panel$year), "-", max(county_panel$year))
  ),
  "output/text/data_build_summary.txt"
)
