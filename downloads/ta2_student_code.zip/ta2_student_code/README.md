# Finance 4 TA2 Student Code

This folder is the **student-facing TA2 package**. It is separate from the website source on purpose.

## What students should do

1. Open `Finance4_TA2_Student.Rproj`
2. Open `main.R`
3. Run:

```r
source("main.R")
```

That script will:

- build a compact synthetic event-study dataset,
- run the TA2 event-study analysis,
- export LaTeX tables to `output/tables/`,
- save figures, tables, and model outputs into `output/`.

## What is inside

```text
ta2_student_code/
  code/
    00_utils.R
    01_build_ta2_data.R
    02_ta2_event_study.R
  Finance4_TA2_Student.Rproj
  main.R
  run_ta2.R
```

## Output files

After running the code, students should find:

- `data/event_panel.rds`
- `data/event_panel.csv`
- `data/data_dictionary.csv`
- `output/figures/ta2_event_study_aar.png`
- `output/figures/ta2_event_study_car.png`
- `output/tables/ta2_data_summary.csv`
- `output/tables/ta2_event_path_summary.csv`
- `output/tables/ta2_window_summary.csv`
- `output/tables/ta2_window_test_table.csv`
- `output/tables/ta2_window_test_table.tex`
- `output/tables/ta2_model_table.csv`
- `output/tables/ta2_regression.tex`
- `output/models/ta2_models.rds`
- `output/text/ta2_note.txt`

## Packages

The TA2 package expects these packages to be installed:

- `broom`
- `dplyr`
- `fixest`
- `ggplot2`
- `knitr`
- `kableExtra`
- `purrr`
- `readr`
- `tidyr`

If a package is missing, the script will stop and tell the student which one to install.
