required_packages <- c(
  "broom",
  "dplyr",
  "fixest",
  "ggplot2",
  "knitr",
  "kableExtra",
  "purrr",
  "readr",
  "tidyr"
)

load_finance4_packages <- function() {
  missing_packages <- required_packages[
    !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  ]

  if (length(missing_packages) > 0) {
    stop(
      paste(
        "Missing packages:",
        paste(missing_packages, collapse = ", "),
        "\nInstall them with install.packages() before running TA2."
      ),
      call. = FALSE
    )
  }

  invisible(lapply(required_packages, library, character.only = TRUE))
  fixest::setFixest_notes(FALSE)
}

ensure_dir <- function(path) {
  if (!dir.exists(path)) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
}

theme_finance4 <- function() {
  ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", color = "#1f2733"),
      plot.subtitle = ggplot2::element_text(color = "#5a6573"),
      axis.title = ggplot2::element_text(color = "#1f2733"),
      axis.text = ggplot2::element_text(color = "#44505e"),
      panel.grid.minor = ggplot2::element_blank(),
      legend.position = "bottom",
      legend.title = ggplot2::element_blank()
    )
}

save_plot_finance4 <- function(plot, path, width = 8, height = 5, dpi = 300) {
  ensure_dir(dirname(path))
  ggplot2::ggsave(filename = path, plot = plot, width = width, height = height, dpi = dpi)
}

write_csv_finance4 <- function(data, path) {
  ensure_dir(dirname(path))
  readr::write_csv(data, path)
}

save_rds_finance4 <- function(object, path) {
  ensure_dir(dirname(path))
  saveRDS(object, path)
}

write_text_finance4 <- function(lines, path) {
  ensure_dir(dirname(path))
  writeLines(lines, path)
}

write_tex_finance4 <- function(tex_string, path) {
  ensure_dir(dirname(path))
  writeLines(as.character(tex_string), path)
}
