# ============================================================
#  FINANCE 4 — TA SESSION 2
#  Script 01: Build the TA2 event-study dataset
# ------------------------------------------------------------
#  This script creates a compact synthetic event panel tailored
#  to event studies. The goal is to keep the TA2 package fully
#  portable while preserving the same intuition as the main
#  course dataset: fragile banks react more negatively to
#  supervisory announcements.
# ============================================================

source("code/00_utils.R")
load_finance4_packages()

set.seed(4404)

ensure_dir("data")
ensure_dir("output/figures")
ensure_dir("output/models")
ensure_dir("output/tables")
ensure_dir("output/text")

# ---- Core event-study ingredients ----------------------------
# We create one supervisory announcement per year and one event
# path per bank around that date.

years <- 2016:2023

year_tbl <- tibble::tibble(
  year = years,
  event_date = as.Date(sprintf("%d-06-28", years)),
  rate_shock = c(0.12, 0.10, 0.06, 0.08, 0.18, 0.30, 0.55, 0.25),
  announcement_intensity = c(0.16, 0.18, 0.18, 0.20, 0.26, 0.32, 0.48, 0.34)
)

banks <- tibble::tibble(
  bank_id = sprintf("B%03d", 1:40),
  bank_name = paste("Bank", sprintf("%03d", 1:40)),
  initial_assets_bn = round(exp(rnorm(40, log(11.5), 0.35)), 2),
  fragility_base = pmin(pmax(stats::rbeta(40, 2.2, 2.8), 0.05), 0.90),
  capital_base = pmin(pmax(rnorm(40, 0.115, 0.015), 0.075), 0.18),
  political_connection = pmin(pmax(stats::rbeta(40, 1.8, 3.0), 0.02), 0.95)
)

# ---- Event-level bank panel ----------------------------------
# Banks cross the same 10bn threshold as in the main dataset.

event_base <- tidyr::crossing(banks, year_tbl) |>
  dplyr::group_by(bank_id) |>
  dplyr::arrange(year, .by_group = TRUE) |>
  dplyr::mutate(
    event_name = paste("Stress Test", year),
    asset_growth = pmin(
      pmax(0.045 - 0.010 * fragility_base + 0.010 * political_connection + rnorm(dplyr::n(), 0, 0.02), -0.04),
      0.16
    ),
    assets_bn = initial_assets_bn * cumprod(1 + asset_growth),
    first_treat = {
      crossing_years <- year[assets_bn >= 10]
      if (length(crossing_years) == 0) 0L else min(crossing_years)
    },
    treated = as.integer(first_treat > 0 & year >= first_treat),
    fragility_iv = fragility_base * rate_shock,
    capital_ratio = pmin(
      pmax(
        capital_base -
          0.018 * fragility_iv -
          0.006 * treated * announcement_intensity +
          0.005 * political_connection +
          rnorm(dplyr::n(), 0, 0.006),
        0.06
      ),
      0.20
    )
  ) |>
  dplyr::ungroup()

# ---- Event-day panel -----------------------------------------
# Abnormal returns are generated so that fragile banks receive a
# more negative reaction on the event day and in the two days
# after the announcement.

event_panel <- tidyr::crossing(event_base, relative_day = -5:5) |>
  dplyr::group_by(bank_id, year) |>
  dplyr::arrange(relative_day, .by_group = TRUE) |>
  dplyr::mutate(
    abnormal_return = rnorm(dplyr::n(), 0, 0.008) +
      dplyr::if_else(
        relative_day == 0,
        0.014 * capital_ratio - 0.045 * fragility_iv + 0.006 * political_connection - 0.004 * treated,
        0
      ) +
      dplyr::if_else(
        relative_day %in% 1:2,
        -0.010 * fragility_iv + 0.002 * capital_ratio,
        0
      ),
    car = cumsum(abnormal_return),
    calendar_date = event_date + relative_day
  ) |>
  dplyr::ungroup() |>
  dplyr::mutate(
    fragility_group = dplyr::if_else(
      fragility_iv >= stats::median(fragility_iv),
      "High fragility",
      "Low fragility"
    )
  )

data_dictionary <- tibble::tribble(
  ~object, ~variable, ~definition, ~economic_role,
  "event_panel", "bank_id", "Synthetic bank identifier", "Event-study panel identifier",
  "event_panel", "year", "Announcement year", "Event-year index",
  "event_panel", "relative_day", "Trading day relative to the event date", "Event-time index",
  "event_panel", "abnormal_return", "Daily abnormal stock return around the event", "Main event-study outcome",
  "event_panel", "car", "Cumulative abnormal return up to the given day", "Dynamic market reaction",
  "event_panel", "fragility_iv", "Bank fragility interacted with the common rate shock", "Exposure measure",
  "event_panel", "fragility_group", "High- vs low-fragility split using the median exposure", "Teaching split for plots and tests",
  "event_panel", "treated", "Indicator for being above the regulatory threshold", "Regulatory control variable"
)

save_rds_finance4(event_panel, "data/event_panel.rds")
write_csv_finance4(event_panel, "data/event_panel.csv")
write_csv_finance4(data_dictionary, "data/data_dictionary.csv")

write_text_finance4(
  c(
    "TA2 event-study data were built successfully.",
    paste("Banks:", dplyr::n_distinct(event_panel$bank_id)),
    paste("Events:", dplyr::n_distinct(paste(event_panel$bank_id, event_panel$year))),
    paste("Event window:", min(event_panel$relative_day), "to", max(event_panel$relative_day))
  ),
  "output/text/data_build_summary.txt"
)
