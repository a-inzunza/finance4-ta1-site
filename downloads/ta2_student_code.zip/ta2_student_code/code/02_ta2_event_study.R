source("code/00_utils.R")
load_finance4_packages()

# ============================================================
#  FINANCE 4 — TA SESSION 2
#  Script 02: Event studies through supervisory announcements
# ------------------------------------------------------------
#  Run from the project root (ta2_student_code/) after 01.
#  Outputs go to output/figures/, output/tables/, output/text/.
# ============================================================


# ############################################################
# SECTION 1 — LOAD THE EVENT-STUDY DATA
# ############################################################

event_panel <- readRDS("data/event_panel.rds")

event_data_summary <- event_panel |>
  dplyr::summarise(
    n_event_day_rows = dplyr::n(),
    n_events = dplyr::n_distinct(paste(bank_id, year)),
    n_banks = dplyr::n_distinct(bank_id),
    first_event_year = min(year),
    last_event_year = max(year),
    min_relative_day = min(relative_day),
    max_relative_day = max(relative_day)
  )


# ############################################################
# SECTION 2 — AVERAGE ABNORMAL RETURNS AND CAR PATHS
# ############################################################
# mean_abnormal_return = average daily reaction at each relative day
# mean_car             = average cumulative reaction up to that day

event_path_summary <- event_panel |>
  dplyr::group_by(relative_day, fragility_group) |>
  dplyr::summarise(
    mean_abnormal_return = mean(abnormal_return),
    mean_car = mean(car),
    sd_abnormal_return = stats::sd(abnormal_return),
    n_event_days = dplyr::n(),
    .groups = "drop"
  )


# ############################################################
# SECTION 3 — COLLAPSE TO ONE ROW PER EVENT
# ############################################################

event_level_panel <- event_panel |>
  dplyr::group_by(bank_id, bank_name, year, event_name, event_date, fragility_group) |>
  dplyr::summarise(
    fragility_iv = dplyr::first(fragility_iv),
    capital_ratio = dplyr::first(capital_ratio),
    political_connection = dplyr::first(political_connection),
    treated = dplyr::first(treated),
    day0_ar = abnormal_return[relative_day == 0][1],
    car_m1_p1 = sum(abnormal_return[relative_day >= -1 & relative_day <= 1]),
    car_0_2 = sum(abnormal_return[relative_day >= 0 & relative_day <= 2]),
    car_m2_p2 = sum(abnormal_return[relative_day >= -2 & relative_day <= 2]),
    .groups = "drop"
  )

window_summary <- event_level_panel |>
  dplyr::transmute(
    fragility_group,
    `Day 0 AR` = day0_ar,
    `CAR(-1,+1)` = car_m1_p1,
    `CAR(0,+2)` = car_0_2,
    `CAR(-2,+2)` = car_m2_p2
  ) |>
  tidyr::pivot_longer(
    cols = -fragility_group,
    names_to = "window",
    values_to = "value"
  ) |>
  dplyr::group_by(fragility_group, window) |>
  dplyr::summarise(
    mean_return = mean(value),
    sd_return = stats::sd(value),
    median_return = stats::median(value),
    n_events = dplyr::n(),
    .groups = "drop"
  )


# ############################################################
# SECTION 4 — EVENT-STUDY TESTS
# ############################################################

event_windows <- c(
  day0_ar = "Day 0 AR",
  car_m1_p1 = "CAR(-1,+1)",
  car_0_2 = "CAR(0,+2)",
  car_m2_p2 = "CAR(-2,+2)"
)

summarise_window_tests <- function(label, variable_name) {
  high_values <- event_level_panel[[variable_name]][event_level_panel$fragility_group == "High fragility"]
  low_values <- event_level_panel[[variable_name]][event_level_panel$fragility_group == "Low fragility"]

  tibble::tibble(
    window = label,
    mean_high = mean(high_values),
    mean_low = mean(low_values),
    diff_high_minus_low = mean(high_values) - mean(low_values),
    p_high_eq_zero = stats::t.test(high_values, mu = 0)$p.value,
    p_low_eq_zero = stats::t.test(low_values, mu = 0)$p.value,
    p_high_eq_low = stats::t.test(high_values, low_values)$p.value
  )
}

window_test_table <- purrr::imap_dfr(event_windows, summarise_window_tests) |>
  dplyr::mutate(
    dplyr::across(
      c(mean_high, mean_low, diff_high_minus_low, p_high_eq_zero, p_low_eq_zero, p_high_eq_low),
      ~round(.x, 4)
    )
  )


# ############################################################
# SECTION 5 — CROSS-SECTIONAL EVENT-STUDY REGRESSIONS
# ############################################################

day0_model <- fixest::feols(
  day0_ar ~ fragility_iv + capital_ratio + political_connection + treated | year,
  cluster = ~bank_id,
  data = event_level_panel
)

car_m1_p1_model <- fixest::feols(
  car_m1_p1 ~ fragility_iv + capital_ratio + political_connection + treated | year,
  cluster = ~bank_id,
  data = event_level_panel
)

car_0_2_model <- fixest::feols(
  car_0_2 ~ fragility_iv + capital_ratio + political_connection + treated | year,
  cluster = ~bank_id,
  data = event_level_panel
)

ta2_models <- list(
  `Day 0 AR` = day0_model,
  `CAR(-1,+1)` = car_m1_p1_model,
  `CAR(0,+2)` = car_0_2_model
)

ta2_model_table <- dplyr::bind_rows(
  broom::tidy(day0_model) |> dplyr::mutate(model = "Day 0 AR"),
  broom::tidy(car_m1_p1_model) |> dplyr::mutate(model = "CAR(-1,+1)"),
  broom::tidy(car_0_2_model) |> dplyr::mutate(model = "CAR(0,+2)")
) |>
  dplyr::select(model, dplyr::everything())


# ############################################################
# SECTION 6 — PLOTS
# ############################################################

event_aar_plot <- ggplot2::ggplot(
  event_path_summary,
  ggplot2::aes(x = relative_day, y = mean_abnormal_return, color = fragility_group)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "#6c757d") +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = "#9a462f") +
  ggplot2::geom_line(linewidth = 1) +
  ggplot2::geom_point(size = 2) +
  ggplot2::labs(
    title = "Average abnormal returns around the supervisory announcement",
    subtitle = "High-fragility banks react more negatively on and just after the event date.",
    x = "Trading days relative to the event",
    y = "Average abnormal return"
  ) +
  theme_finance4()

event_car_plot <- ggplot2::ggplot(
  event_path_summary,
  ggplot2::aes(x = relative_day, y = mean_car, color = fragility_group)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "#6c757d") +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = "#9a462f") +
  ggplot2::geom_line(linewidth = 1) +
  ggplot2::geom_point(size = 2) +
  ggplot2::labs(
    title = "Cumulative abnormal returns around the supervisory announcement",
    subtitle = "The gap in CARs shows that the market expects more pain for fragile banks.",
    x = "Trading days relative to the event",
    y = "Average cumulative abnormal return"
  ) +
  theme_finance4()


# ############################################################
# SECTION 7 — LATEX EXPORT
# ############################################################

window_latex <- knitr::kable(
  window_test_table,
  format = "latex",
  booktabs = TRUE,
  digits = 4,
  col.names = c(
    "Window",
    "Mean (High fragility)",
    "Mean (Low fragility)",
    "High - Low",
    "p-value: High = 0",
    "p-value: Low = 0",
    "p-value: High = Low"
  ),
  caption = "Event-window reactions by fragility group"
) |>
  kableExtra::kable_styling(
    latex_options = c("hold_position"),
    full_width = FALSE
  )

regression_latex <- fixest::etable(
  ta2_models,
  cluster = ~bank_id,
  tex = TRUE
)


# ############################################################
# SECTION 8 — SAVE OUTPUTS
# ############################################################

save_plot_finance4(event_aar_plot, "output/figures/ta2_event_study_aar.png")
save_plot_finance4(event_car_plot, "output/figures/ta2_event_study_car.png")
save_rds_finance4(ta2_models, "output/models/ta2_models.rds")
save_rds_finance4(event_level_panel, "output/models/ta2_event_level_panel.rds")

write_csv_finance4(event_data_summary, "output/tables/ta2_data_summary.csv")
write_csv_finance4(event_path_summary, "output/tables/ta2_event_path_summary.csv")
write_csv_finance4(window_summary, "output/tables/ta2_window_summary.csv")
write_csv_finance4(window_test_table, "output/tables/ta2_window_test_table.csv")
write_csv_finance4(ta2_model_table, "output/tables/ta2_model_table.csv")

write_tex_finance4(window_latex, "output/tables/ta2_window_test_table.tex")
write_tex_finance4(regression_latex, "output/tables/ta2_regression.tex")

write_text_finance4(
  c(
    "TA2 teaching note",
    "",
    "1. Event studies use sharply timed information to recover market-implied effects.",
    "2. In this synthetic case, abnormal returns are already net of expected returns.",
    "3. The key comparison is high-fragility versus low-fragility banks around day 0.",
    "4. Short CAR windows aggregate noisy daily returns into a clearer signal.",
    "5. Cross-sectional regressions ask whether fragility predicts stronger market reactions after controlling for bank characteristics."
  ),
  "output/text/ta2_note.txt"
)
