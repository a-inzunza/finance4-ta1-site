# Finance 4 TA6 Student Code

**Using AI for research — LLMs in empirical finance**

## Quick start (offline, no API key required)

1. Open `Finance4_TA6_Student.Rproj` in RStudio.
2. Run:

```r
source("main.R")
```

The script uses the bundled LLM cache under `data/llm_cache/` and produces all outputs without an internet connection.

## Running with a live OpenAI API call

1. Get an API key at [platform.openai.com](https://platform.openai.com).
2. Set it in R — **never** hard-code it in a script:

```r
Sys.setenv(OPENAI_API_KEY = "sk-...")
```

3. Open `code/01_ta6_llm_research.R` and change:

```r
REFRESH_CACHE <- TRUE
```

4. Run `source("main.R")`. The script will make 20 API calls (~$0.002) and overwrite the cache.

**Security**: add your `.Renviron` file (which may contain the key) to `.gitignore`. A leaked key is a billing problem.

## What is inside

```text
ta6_student_code/
  code/
    00_utils.R               # packages, helpers, call_llm_cached()
    01_ta6_llm_research.R    # full analysis script
  data/
    ta5_corpus_excerpts.csv  # Wikipedia excerpts from TA5
    ta5_tone_scores.csv      # toy-dictionary scores from TA5
    llm_cache/
      excerpt/               # cached Prompt A responses (15 banks)
      reputation/            # cached Prompt B responses (5 banks)
  Finance4_TA6_Student.Rproj
  main.R
  run_ta6.R
```

## Outputs

After running, `output/` will contain:

- `tables/ta6_llm_analysis.csv` — excerpt-based sentiment for all 15 banks
- `tables/ta6_reputation.csv` — reputation analysis for 5 selected banks
- `tables/ta6_comparison.csv` — three-way comparison: toy dict vs LLM excerpt vs LLM knowledge
- `tables/ta6_cost_estimate.csv` — token counts and cost breakdown
- `figures/ta6_sentiment_dist.png` — distribution of excerpt sentiments
- `figures/ta6_comparison.png` — heatmap comparing the three methods
- `text/ta6_prompts.md` — the exact prompts used
- `text/ta6_note.txt` — summary note

## Key packages

`dplyr`, `ggplot2`, `httr2`, `jsonlite`, `knitr`, `purrr`, `readr`, `stringr`, `tibble`, `tidyr`

## Polite LLM usage checklist

Before sending data to any external LLM API:

1. Is the data public? If it contains personal, confidential, or pre-publication material, check your institution's data governance policy first.
2. Have you cached the responses? You should never call the API twice for the same input.
3. Are you using `temperature = 0` for classification tasks?
4. Have you recorded the exact model version (`gpt-4o-mini-2024-07-18`, not just `gpt-4o-mini`) for your paper's data appendix?
5. Is your API key out of all scripts, environment files committed to git, and shared documents?
