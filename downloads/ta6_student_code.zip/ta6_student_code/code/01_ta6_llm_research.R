# ==============================================================================
#  TA6 — Using AI for research: LLMs in empirical finance (student edition)
# ==============================================================================
#
#  This script runs offline by default using the bundled cache in
#  data/llm_cache/. To make live OpenAI API calls:
#    1. Set your API key: Sys.setenv(OPENAI_API_KEY = "sk-...")
#    2. Change: REFRESH_CACHE <- TRUE
#
#  Cost: ~$0.002 for the full exercise at gpt-4o-mini mid-2025 prices.
# ==============================================================================

source("code/00_utils.R")
load_finance4_packages()

REFRESH_CACHE <- FALSE
LLM_MODEL     <- "gpt-4o-mini"

ensure_dir("output/tables")
ensure_dir("output/figures")
ensure_dir("output/text")

# Load the TA5 corpus (bundled in data/).
corpus     <- readr::read_csv("data/ta5_corpus_excerpts.csv", show_col_types = FALSE)
tone_scores <- readr::read_csv("data/ta5_tone_scores.csv",     show_col_types = FALSE)

# --- PROMPTS ------------------------------------------------------------------

system_prompt_excerpt <- paste0(
  "You are a financial analyst assistant. Analyze the provided Wikipedia excerpt ",
  "about a bank and return a JSON object with EXACTLY these fields:\n",
  "  sentiment       : one of 'positive', 'neutral', or 'negative'\n",
  "  sentiment_reason: a single sentence explaining the sentiment\n",
  "  business_lines  : an array of strings listing main activities mentioned\n",
  "  summary         : a single sentence describing what the bank does\n",
  "Base your assessment ONLY on the provided text. Do not use outside knowledge."
)

system_prompt_reputation <- paste0(
  "You are a financial analyst assistant with broad knowledge of the banking industry. ",
  "Based on your general knowledge (not limited to any excerpt), assess the bank's ",
  "reputation and controversies. Return a JSON object with EXACTLY these fields:\n",
  "  reputation_assessment: one of 'positive', 'neutral', or 'negative'\n",
  "  key_controversies    : an array of 2-4 strings, each describing one issue\n",
  "  summary              : a single sentence summarising the reputation assessment"
)

write_text_finance4(
  c("Prompt A (excerpt-only):", system_prompt_excerpt,
    "", "Prompt B (general knowledge):", system_prompt_reputation),
  "output/text/ta6_prompts.md"
)

# --- SECTION 1: EXCERPT-BASED ANALYSIS (all 15 banks) ------------------------

slugify_simple <- function(x) {
  x |>
    stringr::str_to_lower() |>
    stringr::str_replace_all("[^a-z0-9]+", "_") |>
    stringr::str_remove_all("^_|_$")
}

excerpt_results_raw <- corpus |>
  dplyr::mutate(
    slug       = slugify_simple(bank_name),
    cache_path = file.path("data/llm_cache/excerpt", paste0(slug, ".json")),
    user_prompt = paste0("Analyze this Wikipedia excerpt about ", bank_name, ":\n\n", excerpt)
  ) |>
  dplyr::mutate(
    llm_response = purrr::map2(
      user_prompt, cache_path,
      ~ call_llm_cached(.x, system_prompt_excerpt, .y,
                        model = LLM_MODEL, temperature = 0, refresh = REFRESH_CACHE)
    )
  )

llm_analysis <- excerpt_results_raw |>
  dplyr::mutate(
    sentiment        = purrr::map_chr(llm_response, "sentiment"),
    sentiment_reason = purrr::map_chr(llm_response, "sentiment_reason"),
    business_lines   = purrr::map_chr(llm_response, ~ paste(.x[["business_lines"]], collapse = "; ")),
    llm_summary      = purrr::map_chr(llm_response, "summary"),
    prompt_tokens    = purrr::map_int(llm_response, ~ as.integer(.x[["usage_prompt_tokens"]] %||% NA_integer_)),
    completion_tokens = purrr::map_int(llm_response, ~ as.integer(.x[["usage_completion_tokens"]] %||% NA_integer_))
  ) |>
  dplyr::select(rank, bank_name, sentiment, sentiment_reason,
                business_lines, llm_summary, prompt_tokens, completion_tokens)

write_csv_finance4(llm_analysis, "output/tables/ta6_llm_analysis.csv")

sentiment_counts <- llm_analysis |>
  dplyr::count(sentiment, name = "n_banks") |>
  dplyr::mutate(sentiment = factor(sentiment, levels = c("positive", "neutral", "negative")))

sentiment_dist_plot <- ggplot2::ggplot(
  sentiment_counts,
  ggplot2::aes(x = sentiment, y = n_banks, fill = sentiment)
) +
  ggplot2::geom_col(width = 0.6, alpha = 0.9) +
  ggplot2::scale_fill_manual(
    values = c("positive" = "#3b6fab", "neutral" = "#aaaaaa", "negative" = "#a85738"),
    guide  = "none"
  ) +
  ggplot2::geom_text(ggplot2::aes(label = n_banks), vjust = -0.5, size = 4) +
  ggplot2::labs(title = "Excerpt-based sentiment from GPT-4o-mini",
                subtitle = "Each bank's Wikipedia excerpt classified at temperature = 0",
                x = "Sentiment", y = "Number of banks") +
  theme_finance4()

save_plot_finance4(sentiment_dist_plot, "output/figures/ta6_sentiment_dist.png", height = 4)

# --- SECTION 2: REPUTATION ANALYSIS (5 selected banks) -----------------------

reputation_banks <- tibble::tibble(
  bank_name = c("Wells Fargo", "Goldman Sachs", "TD Bank, N.A.",
                "Citigroup", "JPMorgan Chase"),
  slug = slugify_simple(bank_name)
)

reputation_results_raw <- reputation_banks |>
  dplyr::mutate(
    cache_path  = file.path("data/llm_cache/reputation", paste0(slug, ".json")),
    user_prompt = paste0("Assess the broader reputation and key controversies of ", bank_name, ".")
  ) |>
  dplyr::mutate(
    llm_response = purrr::map2(
      user_prompt, cache_path,
      ~ call_llm_cached(.x, system_prompt_reputation, .y,
                        model = LLM_MODEL, temperature = 0, refresh = REFRESH_CACHE)
    )
  )

reputation_analysis <- reputation_results_raw |>
  dplyr::mutate(
    rep_assessment    = purrr::map_chr(llm_response, "reputation_assessment"),
    key_controversies = purrr::map_chr(llm_response, ~ paste(.x[["key_controversies"]], collapse = " | ")),
    rep_summary       = purrr::map_chr(llm_response, "summary"),
    prompt_tokens     = purrr::map_int(llm_response, ~ as.integer(.x[["usage_prompt_tokens"]] %||% NA_integer_)),
    completion_tokens = purrr::map_int(llm_response, ~ as.integer(.x[["usage_completion_tokens"]] %||% NA_integer_))
  ) |>
  dplyr::select(bank_name, rep_assessment, key_controversies, rep_summary,
                prompt_tokens, completion_tokens)

write_csv_finance4(reputation_analysis, "output/tables/ta6_reputation.csv")

# --- SECTION 3: THREE-WAY COMPARISON -----------------------------------------

tone_labelled <- tone_scores |>
  dplyr::mutate(
    dict_sentiment = dplyr::case_when(
      tone > 0.005  ~ "positive",
      tone < -0.005 ~ "negative",
      TRUE          ~ "neutral"
    )
  ) |>
  dplyr::select(bank_name, dict_sentiment, tone)

comparison <- reputation_banks |>
  dplyr::left_join(llm_analysis |> dplyr::select(bank_name, llm_excerpt_sentiment = sentiment), by = "bank_name") |>
  dplyr::left_join(reputation_analysis |> dplyr::select(bank_name, llm_rep_sentiment = rep_assessment), by = "bank_name") |>
  dplyr::left_join(tone_labelled, by = "bank_name") |>
  dplyr::select(bank_name, dict_sentiment, llm_excerpt_sentiment, llm_rep_sentiment, tone)

write_csv_finance4(comparison, "output/tables/ta6_comparison.csv")

comparison_long <- comparison |>
  tidyr::pivot_longer(
    cols = c(dict_sentiment, llm_excerpt_sentiment, llm_rep_sentiment),
    names_to = "method", values_to = "sentiment"
  ) |>
  dplyr::mutate(
    method = factor(method,
      levels = c("dict_sentiment", "llm_excerpt_sentiment", "llm_rep_sentiment"),
      labels = c("Toy dictionary\n(TA5)", "LLM — excerpt only\n(Prompt A)",
                 "LLM — general knowledge\n(Prompt B)")
    ),
    sentiment = factor(sentiment, levels = c("positive", "neutral", "negative")),
    bank_name = factor(bank_name, levels = rev(unique(bank_name)))
  )

comparison_plot <- ggplot2::ggplot(
  comparison_long,
  ggplot2::aes(x = method, y = bank_name, fill = sentiment)
) +
  ggplot2::geom_tile(colour = "white", linewidth = 1.2) +
  ggplot2::scale_fill_manual(
    values = c("positive" = "#3b6fab", "neutral" = "#aaaaaa", "negative" = "#a85738")
  ) +
  ggplot2::labs(title = "Three ways to classify bank sentiment — do they agree?",
                x = NULL, y = NULL, fill = "Sentiment") +
  ggplot2::theme_minimal(base_size = 12) +
  ggplot2::theme(plot.title = ggplot2::element_text(face = "bold"),
                 panel.grid = ggplot2::element_blank())

save_plot_finance4(comparison_plot, "output/figures/ta6_comparison.png", height = 4, width = 9)

# --- SECTION 4: COST ESTIMATE ------------------------------------------------

price_input  <- 0.15  # USD per 1M tokens
price_output <- 0.60

all_tokens <- dplyr::bind_rows(
  llm_analysis     |> dplyr::mutate(prompt_type = "Prompt A — excerpt") |>
    dplyr::select(bank_name, prompt_type, prompt_tokens, completion_tokens),
  reputation_analysis |> dplyr::mutate(prompt_type = "Prompt B — reputation") |>
    dplyr::select(bank_name, prompt_type, prompt_tokens, completion_tokens)
)

cost_table <- all_tokens |>
  dplyr::group_by(prompt_type) |>
  dplyr::summarise(
    n_calls = dplyr::n(),
    total_input  = sum(prompt_tokens, na.rm = TRUE),
    total_output = sum(completion_tokens, na.rm = TRUE),
    .groups = "drop"
  ) |>
  dplyr::mutate(
    cost_input  = total_input  / 1e6 * price_input,
    cost_output = total_output / 1e6 * price_output,
    total_cost  = cost_input + cost_output
  )

write_csv_finance4(cost_table, "output/tables/ta6_cost_estimate.csv")

# --- SECTION 5: TEACHING NOTE ------------------------------------------------

write_text_finance4(
  c("TA6 — LLMs in empirical finance (student edition)",
    "",
    paste0("Banks analysed (excerpt):     ", nrow(llm_analysis)),
    paste0("Banks analysed (reputation):  ", nrow(reputation_analysis)),
    paste0("Total API cost (~$0.002 live, $0 offline): see ta6_cost_estimate.csv"),
    "",
    "Key comparison:",
    "  Wells Fargo: toy dict neutral, LLM excerpt neutral, LLM knowledge NEGATIVE",
    "  TD Bank:     toy dict negative (word 'risk'), LLM excerpt neutral, LLM knowledge NEGATIVE",
    "  Goldman:     toy dict positive, LLM excerpt positive, LLM knowledge NEUTRAL"),
  "output/text/ta6_note.txt"
)
