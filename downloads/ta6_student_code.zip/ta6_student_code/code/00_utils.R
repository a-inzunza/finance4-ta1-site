required_packages <- c(
  "dplyr",
  "ggplot2",
  "httr2",
  "jsonlite",
  "knitr",
  "purrr",
  "readr",
  "stringr",
  "tibble",
  "tidyr"
)

load_finance4_packages <- function() {
  missing_packages <- required_packages[
    !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing_packages) > 0) {
    stop(
      paste(
        "Missing packages:", paste(missing_packages, collapse = ", "),
        "\nInstall them with install.packages() before running TA6."
      ),
      call. = FALSE
    )
  }
  invisible(lapply(required_packages, library, character.only = TRUE))
}

ensure_dir <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

theme_finance4 <- function() {
  ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      plot.title    = ggplot2::element_text(face = "bold", color = "#1f2733"),
      plot.subtitle = ggplot2::element_text(color = "#5a6573"),
      axis.title    = ggplot2::element_text(color = "#1f2733"),
      axis.text     = ggplot2::element_text(color = "#44505e"),
      panel.grid.minor = ggplot2::element_blank(),
      legend.position  = "bottom",
      legend.title     = ggplot2::element_blank()
    )
}

save_plot_finance4 <- function(plot, path, width = 8, height = 5, dpi = 300) {
  ensure_dir(dirname(path))
  ggplot2::ggsave(filename = path, plot = plot, width = width, height = height, dpi = dpi)
}

write_csv_finance4 <- function(data, path) {
  ensure_dir(dirname(path))
  readr::write_csv(data, path)
}

write_text_finance4 <- function(lines, path) {
  ensure_dir(dirname(path))
  writeLines(lines, path)
}

write_tex_finance4 <- function(tex_string, path) {
  ensure_dir(dirname(path))
  writeLines(as.character(tex_string), path)
}

#' Call the OpenAI Chat Completions API with a disk cache.
#' Set OPENAI_API_KEY with: Sys.setenv(OPENAI_API_KEY = "sk-...")
#' Keep REFRESH_CACHE = FALSE (default) to run offline using bundled cache.
call_llm_cached <- function(user_prompt,
                             system_prompt,
                             cache_path,
                             model       = "gpt-4o-mini",
                             temperature = 0,
                             refresh     = FALSE) {
  ensure_dir(dirname(cache_path))

  if (file.exists(cache_path) && !refresh) {
    return(jsonlite::fromJSON(readLines(cache_path, warn = FALSE)))
  }

  api_key <- Sys.getenv("OPENAI_API_KEY")
  if (!nzchar(api_key)) {
    stop(
      "OPENAI_API_KEY is not set.\n",
      "Set it with: Sys.setenv(OPENAI_API_KEY = 'sk-...')\n",
      "Or keep REFRESH_CACHE = FALSE to use the bundled offline cache.",
      call. = FALSE
    )
  }

  resp <- httr2::request("https://api.openai.com/v1/chat/completions") |>
    httr2::req_auth_bearer_token(api_key) |>
    httr2::req_body_json(list(
      model           = model,
      temperature     = temperature,
      response_format = list(type = "json_object"),
      messages        = list(
        list(role = "system", content = system_prompt),
        list(role = "user",   content = user_prompt)
      )
    )) |>
    httr2::req_retry(max_tries = 3, backoff = ~ 5L) |>
    httr2::req_perform()

  raw_content <- httr2::resp_body_json(resp)$choices[[1]]$message$content
  usage       <- httr2::resp_body_json(resp)$usage
  parsed      <- jsonlite::fromJSON(raw_content)
  parsed$usage_prompt_tokens     <- usage$prompt_tokens
  parsed$usage_completion_tokens <- usage$completion_tokens

  writeLines(jsonlite::toJSON(parsed, auto_unbox = TRUE, pretty = TRUE), cache_path)
  parsed
}
