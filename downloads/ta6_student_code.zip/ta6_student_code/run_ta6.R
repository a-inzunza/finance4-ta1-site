get_run_ta6_path <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_matches <- grep("^--file=", cmd_args, value = TRUE)
  if (length(file_matches) > 0) {
    return(normalizePath(sub("^--file=", "", file_matches[length(file_matches)]),
                         winslash = "/", mustWork = TRUE))
  }
  frame_files <- vapply(sys.frames(), function(f) {
    o <- f$ofile; if (is.null(o)) "" else o
  }, character(1))
  frame_files <- frame_files[nzchar(frame_files)]
  if (length(frame_files) > 0) {
    return(normalizePath(frame_files[length(frame_files)], winslash = "/", mustWork = TRUE))
  }
  stop("Could not determine location of run_ta6.R.", call. = FALSE)
}

original_wd <- getwd()
on.exit(setwd(original_wd), add = TRUE)
setwd(dirname(get_run_ta6_path()))

source("code/01_ta6_llm_research.R")

message("TA6 student outputs created in: ", normalizePath("output", winslash = "/"))
